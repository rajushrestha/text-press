<?
// personal tool
// (c)2012 by Muhammad Fauzan Sholihin	tecnixindo@gmail.com	Ph/SMS 02747427749
// www.tetuku.com	www.pricebill.com
// Godean Jogja Indonesia

if ($_POST['target_url'] != '') {

$curl = curl_init();
$pecah = explode('/',$_POST['target_url']);
$count = (count($pecah))-1;
$saveTo = $pecah[$count];
$fp = fopen('./files/'.$saveTo, 'w');
curl_setopt($curl, CURLOPT_URL, $_POST['target_url']);
curl_setopt($curl, CURLOPT_FILE, $fp);
curl_setopt($curl, CURLOPT_USERAGENT, base64_decode('TW96aWxsYS81LjAgKFdpbmRvd3M7IFU7IFdpbmRvd3MgTlQgNS4xOyBydTsgcnY6MS45LjIuMTEpIEdlY2tvLzIwMTAxMDEyIEZpcmVmb3gvMy42LjEx'));
curl_exec ($curl);
curl_close ($curl);
fclose($fp);

echo "<h1>finish..!</h1><hr>";
}
?>
<form name="form1" method="post" action="">
  Target URL: 
  <input name="target_url" type="text" id="target_url" size="44">
  <input type="submit" name="Submit" value=" ::. Import">
  <br>
  <em>This tool is used to import file from another website </em> 
</form>
