<?php include_once "ijin_user.inc.php";?>
<?php
include_once "functions.inc.php";


// untuk di olah di meta, keyword pisahkan dengan spasi
$title = $content_detil[3];
$desc = strip_tags(cuplik($content_detil[4],180));
$kw = $path[0]." ".$content_detil[3];

$desc = substr(strip_tags($desc),0,180);
if (strlen($desc) < 60) {$desc = $desc." ".$setting[1];}
$kw = preg_replace('/[^A-Za-z0-9]/',' ',trim($kw));
	$ar_kw = explode(' ',$kw);
	$kw = "";
	foreach ($ar_kw as $item) {
		if (strlen($item) > 3) {$kw .= $item.","; }
	}
	$kw = substr($kw,0,-1);

if (!file_exists('files/template_detail.php')) {$template = read_file('template_detail.php');}
if (file_exists('files/template_detail.php')) {$template = read_file('files/template_detail.php');}

if (!stristr($template,'jquery')) {$template = str_replace("</body>","<script src=\"http://localhost/texTPress/js/jquery.js\"></script>
</body>",$template);}
if (!stristr($template,'bootstrap')) {$template = str_replace("</head>","<link href=\"".$abs_url."css/bootstrap.css\" rel=\"stylesheet\">
	</head>",$template);
	$template = str_replace("</body>","<script src=\"".$abs_url."js/bootstrap.js\"></script>
	</body>",$template);
	}
if (!stristr($template,'masonry')) {$template = str_replace("</body>","<script src=\"".$abs_url."js/masonry.min.js\"></script>
</body>",$template);}

include_once "page_new.inc.php";
include_once "page_recent.inc.php";
include_once "page_popular.inc.php";
include_once "page_related.inc.php";
include_once "page_widget.inc.php";
include_once "lang.inc.php";

$template0 = in_string('','<!--start content-->',$template);
$template1 = in_string('<!--start content-->','<!--end content-->',$template);
$template2 = in_string('<!--end content-->','',$template);

echo $template0;
?>
<p>&nbsp;</p>
<div class="row">
	<div class="col-md-12 well">
    	You are login as <strong><?=$username[2]?></strong>
    </div>
</div>
<div class="row js-masonry">
	<div class="col-md-6">
    	<h3>License status</h3>
                  <p>
                  <?php if (strlen($setting[InstallDate][3]) > 11) {?>
                License for: 
                <?php echo decrypt($setting[InstallDate][3]);?>
                <a href="<?=$abs_url?>copy-license" class="btn btn-info">Copy  license</a>
                <?php }?>
                <br />
                You are using
                <?php 
                $versi_skr = read_file('versi_textpress.txt'); 
                $versi_baru = access_url('http://text-press.googlecode.com/svn/versi_textpress.txt');
                $num_skr = preg_replace('/[^0-9.]/', '',$versi_skr);
                $num_baru = preg_replace('/[^0-9.]/', '',$versi_baru);
                echo "<a href=http://text-press.googlecode.com/svn/textpress_v".$num_skr.".zip>".$versi_skr."</a>";
                ?> (<?
                if ($num_skr >= $num_baru) {echo "new";}
                if ($num_skr < $num_baru) {echo "new version: <a href=http://text-press.googlecode.com/svn/textpress_v".$num_baru.".zip>".$versi_baru."</a>";}
                        ?>)        
				<?php if (strlen($setting[InstallDate][3]) < 11) {?>
                                Trial Version
                  <br /><br />
                  <a href="<?=$abs_url?>upgrade-textpress" class="btn btn-info">Upgrade now</a>
                <?php }?>
                  </p>
                <p>&nbsp;</p>
	</div>
<!--
	<div class="col-md-6">
   	  <h3>Seting</h3>
        <small>AGC (Auto Generated Content) adalah fitur untuk menghasilkan artikel otomatis</small>
		<div class="row">
        	<div class="col-md-1"></div>
        	<div class="col-md-4 col-xs-6">AGC</div>
            <div class="col-md-4 col-xs-6"><?=$setting[AGC][2]?></div>
        	<div class="col-md-3"></div>
        </div>  
  </div>
-->
	<div class="col-md-6">
    	<h3>Comments</h3>
			<?php
            $row_system_message = read_db('files/message_system.txt',1,10);
$i = 0;
$zebra = - 1;
            foreach ($row_system_message as $column_system_message) {
$zebra = $zebra * (- 1) ;
$i = $i + 1;
            ?>
            <div style="padding:12px; margin:6px; background-color:<? if ($zebra > 0) {echo '#DDDDDD';} else if ($zebra < 0) {echo '#EEEEEE';}?> "><span style="font-size:10pt; color:#666666"><?php echo date('l, d F Y - H:i',strtotime($column_system_message[1])); ?></span> <a href="<?=$column_system_message[2]?>" class="btn btn-info btn-xs">Read &raquo;</a><br /> 
      <?php echo nl2br(stripslashes($column_system_message[3]));?></div>
            <?php }?>
            <p>&nbsp;</p>
    </div>
	<div class="col-md-6">
    	<h3>Login history</h3>
			<?php
            $row_history = read_db('files/login_history.txt',1,5);
            foreach ($row_history as $column_history) {
            ?>
            <p><?=date('d/m/Y H:i',strtotime($column_history[2]))?> <?php if ($column_history[3] != '') {echo " &raquo; ".date('d/m/Y H:i',strtotime($column_history[3]));}?> | <?=$column_history[4]?></p>
            <?php }?> 
            <p>&nbsp;</p>
    </div>
	<div class="col-md-6">
    	<h3>Need attention</h3>
        Improve these pages for better SEO: 
<?php	
	$row_seo_stats = read_db('files/stats_seo.txt',1,100);
	if (count($row_seo_stats) < 2) {echo "<p>No data found</p>";}?>
    </div>
<?php
	$i = 0;
	$z = -1;
	$row_seo_stats = array_sort($row_seo_stats,6,SORT_DESC);
	foreach ($row_seo_stats as $column_seo_stats) {
	$i++;
	$zebra = $zebra * (- 1) ;
	$z = $z + 1;

?>
	<div class="col-md-6">
    	<p>♦ <a href="<?=$abs_url.$column_seo_stats[2]?>/<?=$column_seo_stats[1]?>/edit"><?=$column_seo_stats[3]?></a></p>
    </div>
<?php 
	if ($i >= 12) {break;}
	}
?>
</div>
<?php
echo $template2;
?>
<?php 
if ($pesan != '') {
	echo "<script type=\"text/javascript\">alert('".$pesan."');</script>";
	$pesan = '';
	redirect($_SERVER['REQUEST_URI'], 0.1);
}
?>
