<?php
include_once "functions.inc.php";

// untuk di olah di meta, keyword pisahkan dengan spasi
$title = ucfirst($path[0])." ".$setting[SiteConfig][2];
$desc = $setting[Meta][3];
$kw = $path[0]." ".$setting[Meta][4];

$desc = substr(strip_tags($desc),0,180);
if (strlen($desc) < 60) {$desc = $desc." ".$setting[1];}
$kw = preg_replace('/[^A-Za-z0-9]/',' ',trim($kw));
	$ar_kw = explode(' ',$kw);
	$kw = "";
	foreach ($ar_kw as $item) {
		if (strlen($item) > 3) {$kw .= $item.","; }
	}
	$kw = substr($kw,0,-1);

		$row_home = read_db('files/content_stats.txt',1,1000);

if (!file_exists('files/template_home.php')) {$template = read_file('template_home.php');}
if (file_exists('files/template_home.php')) {$template = read_file('files/template_home.php');}

foreach ($row_home as $column_home) {
		$column_home[5] = date('D, d M Y - H:i',strtotime($column_home[5]));
		$home_list[$column_home[2]][] = $column_home;
}

//print_r($home_list); die();

	$files = file_list('files'); //print_r($files); die();
	foreach ($files as $nama_file) {
		if (stristr($nama_file,'.txt')) {
			$page_type = substr($nama_file,0,-4); //echo $page_type;
			$list = "";
	
			$pola0 = in_string('<!--start '.$page_type.'-->','<!--end '.$page_type.'-->',$template);
			for ($i=0;$i<count($home_list[$page_type]);$i++) {
				$pola1 = str_replace('[]','['.$i.']',$pola0);
				$list .= $pola1;
			}
			
				$template = str_replace($pola0,$list,$template);
			for ($i=0;$i<count($home_list[$page_type]);$i++) {
				if (strlen($home_list[$page_type][$i][3]) > 11 && !stristr($template,$home_list[$page_type][$i][1])) {
					$content_img = in_string('img src="','"',$home_list[$page_type][$i][4]);
					$template = str_replace('{'.$page_type.'_permalink['.$i.']}',$home_list[$page_type][$i][2].'/'.$home_list[$page_type][$i][1],$template);
					$template = str_replace('{'.$page_type.'_date['.$i.']}',$home_list[$page_type][$i][5],$template);
					$template = str_replace('{'.$page_type.'_title['.$i.']}',$home_list[$page_type][$i][3],$template);
					$template = str_replace('{'.$page_type.'_content['.$i.']}',$home_list[$page_type][$i][4],$template);
					$template = str_replace('{'.$page_type.'_img['.$i.']}',$home_list[$page_type][$i][4],$template);
					$template = str_replace('{content_price['.$i.']}',$home_list[$page_type][$i][6],$template);
//					echo $page_type.'_title['.$i.']';
//					echo $home_list[$page_type][$i][3];
				}
			}
		}
	}

$template = str_replace('{abs_url}',$abs_url,$template);
//$head0 = in_string('','</head>',$template);
//$head1 = in_string('</head>','',$template);

include_once "lang.inc.php";
include_once "page_widget.inc.php";

echo $template;

if ($_GET['q'] == 'login') {$pesan = $alert_must_login;}
if ($_GET['q'] == 'logout') {$pesan = $alert_logout;}


?>
<?php
if ($pesan != '') {
	echo "<script type=\"text/javascript\">alert('".$pesan."');</script>";
	$pesan = '';
}
?>
