<?php
include_once "functions.inc.php";

//cek harmoni warna
// If color base is not defined:
if (strlen($setting[SiteConfig][3]) >= 6) {$bgcolor = trim($setting[SiteConfig][3]); setcookie ("bgcolor",$bgcolor,0,'/'); // color base - uncomment to activate
}

if (strlen($_COOKIE['bgcolor']) >= 6) {
$bgcolor = $_COOKIE['bgcolor'];
$mono = unserialize($_COOKIE['mono']);
$analogic = unserialize($_COOKIE['analogic']);
$complement = unserialize($_COOKIE['complement']);
$triad = unserialize($_COOKIE['triad']);
}

if (strlen($_COOKIE['bgcolor']) < 6) {
$rand_r = rand(2,9).rand(3,9);
$rand_g = rand(2,9).rand(3,9);
$rand_b = rand(2,9).rand(3,9);
$bgcolor = "#".$rand_r.$rand_g.$rand_b;
setcookie ("bgcolor",$bgcolor,0,'/'); 
			}
			include_once "color_harmony.inc.php";			

?>
<style type="text/css">

.navbar-inverse {
	background-color: <?=$mono[0]?>;
}

.navbar-header a:visited {
	color: <?=$mono[3]?>;
}

.navbar-nav li a:link {
	color: <?=$mono[3]?>;
}

.nav-tabs a {
	color: <?=$analogic[1]?>;	
	background-color: <?=$mono[3]?>;	
}

.thumb-left img{
	min-width:200px;
	max-width:320px;
	height:auto;
	background-color: #DEDEDE;
	margin: 12px;
	padding: 6px;
	clear: left;
	float: left;
	border: 1px solid #999;
}

.thumb-full img{
	width: 100%;
	height: auto;
	padding-bottom: 9px;
}

.container a {
	color: <?=$analogic[1]?>;	
}

.container a:hover {
	color: <?=$analogic[3]?>;
	text-decoration: underline;
}
</style>