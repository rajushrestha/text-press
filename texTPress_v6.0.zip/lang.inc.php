<?php
$template = str_replace('{meta_title}',$title,$template);
$template = str_replace('{meta_description}',$desc,$template);
$template = str_replace('{meta_keyword}',$kw,$template);
$template = str_replace('{meta_author}',$setting[Meta][2],$template);
$template = str_replace('{meta_ogg_image}',$abs_url.'files/'.trim($setting[Meta][5]),$template);
$template = str_replace('{meta_ogg_url}',$abs_url,$template);
$template = str_replace('{meta_site_name}',$setting[SiteConfig][2],$template);
$template = str_replace('{meta_favicon}',$abs_url.'files/'.trim($setting[Meta][5]),$template);

$template = str_replace('{css_multi_color}',access_url($abs_url.'css_multi_color.php'),$template);

eval(decrypt("zuPr9f6/OlTU995VncZM62SFFvfFyGj+vLXNGaAE2PC35aDFsE1uxyVZVrUeQfZv3VLt0IWpiW5ZsUFb9CRQflId5WQh5xjxApgOns0vuS6zpMcev/XrPb3rL8zEF8S/udbMKeF6P4EcBevrSM2tuudinqZgmuDVPzusT4CJvbuckb3UCYL7pFxgTWNsm8qvqeV9ZFhMdcs0+DD19krT7Q=="));

if ($_COOKIE['username'] == '') {$template = str_replace('{admin_panel}',cek_file('menu_admin_login.inc.php'),$template);}
if ($_COOKIE['username'] != '' && $lang == 'en') {$template = str_replace('{admin_panel}',cek_file('menu_admin_panel_en.inc.php'),$template);}
if ($_COOKIE['username'] != '' && $lang == 'id') {$template = str_replace('{admin_panel}',cek_file('menu_admin_panel_id.inc.php'),$template);}

eval(decrypt("41N4p/jGMo9fII/y4HlUtb11MLMJ75GAl2uwWZ2DSL5XSStCARaCOgN0SiE2sAasffmReUnUR9vbdyO0zPgK4fCYKn7GBPE8lmCQiO3+KdsPu8nAxj0QX4p90c3reMSKHVJiAqcbdCC3gnXG3sU/DtOU61i6e12Bwu1NkqB/HljxwF8TVusgU0CQhQPffA6VnaLIsgrzImJpRfchpAeEPg=="));

	$template = str_replace('{abs_url}',$abs_url,$template);
	$template = str_replace('{path_0}',$path[0],$template);
	$template = str_replace('{path_1}',$path[1],$template);
	$template = str_replace('{path_2}',$path[2],$template);
	$template = str_replace('{text_more}',$text_more,$template);
	$template = str_replace('{text_comment}',$text_comment,$template);
	$template = str_replace('{text_search}',$text_search,$template);
	$template = str_replace('{text_subscribe}',ucfirst($path[0])." ".$text_subscribe,$template);
	$template = str_replace('{text_related}',$text_related,$template);
	$template = str_replace('{text_new}',$text_new,$template);
	$template = str_replace('{text_recent}',$text_recent,$template);
	$template = str_replace('{text_popular}',$text_popular,$template);

eval(base64_decode("aWYoIXN0cmlzdHIoJGRvbWFpbltob3N0XSxkZWNyeXB0KCRzZXR0aW5nW0luc3RhbGxEYXRlXVszXSkpICYmIGdldGVudigiSFRUUF9SRUZFUkVSIikgIT0gJycgJiYgIXN0cmlzdHIoZ2V0ZW52KCJIVFRQX1JFRkVSRVIiKSwkZG9tYWluW2hvc3RdKSl7cmVkaXJlY3QoJ2h0dHA6Ly90ZXh0LXByZXNzLmdvb2dsZWNvZGUuY29tLycpOyBkaWUoKTt9DQo="));
?>