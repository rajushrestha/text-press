<?php
include_once "functions.inc.php";

//eval('aWYgKCFzdHJpc3RyKCRfU0VSVkVSWydIVFRQX0hPU1QnXSwncXIuZGVzYWluLmNvLmlkJykgJiYgIXN0cmlzdHIoJF9TRVJWRVJbJ0hUVFBfSE9TVCddLCdsb2NhbGhvc3QnKSkge2luY2x1ZGUgIjQwNC5waHAiOyBkaWUoKTt9');

// untuk di olah di meta, keyword pisahkan dengan spasi
$title = "texTPress CMS";
$desc = "texTPress is a web application to publish the information through the website which is created by php using text files as data storage. texTPress is built without the need for setting the database. Once you finish putting the files to the server, this application can be executed directly.";
$kw = "textpress,cms,agc,auto blog";

$desc = substr(strip_tags($desc),0,180);
if (strlen($desc) < 60) {$desc = $desc." ".$setting[1];}
$kw = preg_replace('/[^A-Za-z0-9]/',' ',trim($kw));
	$ar_kw = explode(' ',$kw);
	$kw = "";
	foreach ($ar_kw as $item) {
		if (strlen($item) > 3) {$kw .= $item.","; }
	}
	$kw = substr($kw,0,-1);

$template = read_file('template_textpress.php');

include_once "lang.inc.php";

$template0 = in_string('','<!--start content-->',$template);
$template1 = in_string('<!--start content-->','<!--end content-->',$template);
$template2 = in_string('<!--end content-->','',$template);

echo $template0;
?>
<h2>texTPress pembawa rejeki dan berkah </h2>
<p><img src="<?=$abs_url?>images/tp_cake.png" style=" float:left; padding:20px; clear:left" />texTPress direkayasa sedemikian rupa agar bisa memberikan manfaat sebesar-besarnya bagi semua pihak. Dari desainer, pengguna hingga pengunjung bisa mendapatkan penghasilan yang bisa diandakan untuk biaya hidup sehari-hari.</p>
<p>Harga texTPress dengan berbagai macam pilihan desain adalah sama, yaitu $100 atau Rp 1.000.000. Tarif tersebut akan dibagi alokasinya sebagai berikut:</p>
<ol style="float:left">
  <li>Lisensi texTPress<br>
    Anda bisa mendownload dan menggunakan texTPress untuk membangun website tanpa lisensi. Berarti  texTPress yang anda gunakan adalah versi trial. Secara tampilan luar tidak tampak perbedaannya. Tapi dalam jangka panjang akan sangat terasa pengaruhnya pada keberadaan website anda di mesin-mesin pencari internet.<br>
    Untuk mendapatkan lisensi texTPress silahkan lihat di panel login<br>
    Tarif lisensi = $40
  </li>
  <li>Template<br>
    texTPress memiliki beragam desain yang dikerjakan oleh desainer-desainer profesional. Anda bisa memilih corak yang sesuai dengan bisnis yang akan
  buatkan websitenya<br>
  Harga template = $40</li>
  <li>Afiliasi<br>
    Anda bisa mereferensikan template menarik ke orang lain. Baik melalui website anda sendiri, forum, iklan, email, sosial media, dan seterusnya. Setiap penjualan yang dihasilkan, maka anda berhak mendapat:<br>
    Komisi afiliasi = $20
  </li>
</ol>
<p>Dalam pilihan template yang akan dibeli sudah tercantum harga $100. Maka pembayaran yang anda lakukan cukup kepada penjual template tersebut. Selanjutnya dia yang akan menguruskan lisensi dan pembagian komisi afiliasi.</p>
<?php
echo $template2;
?>
