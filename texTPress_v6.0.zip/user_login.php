<?php
include_once "functions.inc.php";


//login by form
if ($_POST['user_email'] != '') {
	$user_key = get_key_db('files/user.txt', $_POST['user_email']);
	$user_data = key_db('files/user.txt',$user_key);
}


if ($_POST['user_email'] != '' && $_POST['user_email'] == $user_data[2] && md5("{[".$_POST['user_psw']."]}") == trim($user_data[3])) {
	setcookie ("username", base64_encode(serialize($user_data)),time()+10000);

	$history[1] = $_POST['user_email'];
	$history[2] = date('Y-m-d H:i:s');	//login
	$history[3] = "";	//logout
	$history[4] = $_SERVER['REMOTE_ADDR'];
	add_db('files/login_history.txt',$history);
	
	redirect ($abs_url."panel"); die();
} 

	if ($_POST['user_email'] != '' && ($_POST['user_email'] != $user_data[2] || md5("{[".$_POST['user_psw']."]}") != $user_data[3])) {
	$pesan = $alert_login_fail;
}


// untuk di olah di meta, keyword pisahkan dengan spasi
$desc = "Halaman untuk login dan masuk area khusus anggota QR Code Indonesia";
$kw = "login anggota qr code";
?><!doctype html>
<html>
<meta charset="utf-8"><title>Login</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="{meta_description}" />
	<meta name="keywords" content="textpress,login" />
	<meta name="author" content="texTPress" />
  	
	<meta property="og:image" content="" />
	<meta property="og:url" content="" />
	<meta property="og:site_name" content="{meta_site_name}" />

<link rel="icon" href="<?=$abs_url?>favicon.png" type="image/x-icon" />
<link rel="shortcut icon" href="<?=$abs_url?>favicon.png" type="image/x-icon" />

    <link href="<?=$abs_url?>css/bootstrap.css" rel="stylesheet">
</head>
<body>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
<div class="container">
		  <div class="row">
		    	<div class="col-md-4">&nbsp;</div>
		    	<div class="col-md-4">
                <form action="" method="post" enctype="multipart/form-data" class="form-signin" role="form">
                <h2 class="form-signin-heading"><?=$text_please?> Login</h2>
                <input name="user_email" type="email" required class="form-control" id="user_email" placeholder="<?=$text_your_email?>" autocomplete="on" size="33">
                <input name="user_psw" type="password" required class="form-control" id="user_psw" placeholder="Password" size="33">
                <label class="checkbox">
                  <input name="ingat" type="checkbox" id="ingat" value="ingat" checked="checked"> <?=$text_remember?>
                </label>
                <input name="submit" type="submit" class="btn btn-lg btn-primary btn-block" id="submit" value="Login">
                </form>
                <p><?=$text_lost_password_question?> <br>
                  <?=$text_please?> <a href="<?=$abs_url?>lost-password">reset password</a></p>
                </div>
		    	<div class="col-md-4">&nbsp;</div>
		  </div>
</div><!--/.container--> 
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
<?php
if ($pesan != '') {
	echo "<script type=\"text/javascript\">alert('".$pesan."');</script>";
	$pesan = '';
}
?>
</body>
</html>
