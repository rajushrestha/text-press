<?php
include_once "functions.inc.php";
/*
		$color_key = get_key_db('files/setting.txt', 'SiteConfig');
		$color_detil = key_db('files/setting.txt',$color_key);

// harmoni warna
$mono = unserialize($color_detil[5]);
$analogic = unserialize($color_detil[6]);
$complement = unserialize($color_detil[7]);
$triad = unserialize($color_detil[8]);
*/

$bgcolor = "#f54828";

	include('color_harmony.class.php');
	$c = new colorHarmony;

	$c->isHEX($bgcolor);

	if($c->HEXError==1) {
		echo $c->HEXErrorMessage;
	} else {


		$mono = $c->Monochromatic($bgcolor);
		$analogic = $c->Analogous($bgcolor);
		$complement = $c->Complementary($bgcolor);
		$triad = $c->Triads($bgcolor);
		$rgba = $c->RGBA($bgcolor);

	}


?>
<table width="100%" border="1" cellspacing="12" cellpadding="6">
  <tr>
    <td width="20%" height="60" align="center" valign="middle">Mono[]</td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$mono[0]?>"><?=$mono[0]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$mono[1]?>"><?=$mono[1]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$mono[2]?>"><?=$mono[2]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$mono[3]?>"><?=$mono[3]?></td>
  </tr>
  <tr>
    <td width="20%" height="60" align="center" valign="middle">&nbsp;</td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$mono[4]?>"><?=$mono[4]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$mono[5]?>"><?=$mono[5]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$mono[6]?>"><?=$mono[6]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$mono[7]?>"><?=$mono[7]?></td>
  </tr>
  <tr>
    <td width="20%" height="60" align="center" valign="middle">Analogic[]</td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$analogic[0]?>"><?=$analogic[0]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$analogic[1]?>"><?=$analogic[1]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$analogic[2]?>"><?=$analogic[2]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$analogic[3]?>"><?=$analogic[3]?></td>
  </tr>
  <tr>
    <td width="20%" height="60" align="center" valign="middle">&nbsp;</td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$analogic[4]?>"><?=$analogic[4]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$analogic[5]?>"><?=$analogic[5]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$analogic[6]?>"><?=$analogic[6]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$analogic[7]?>"><?=$analogic[7]?></td>
  </tr>
  <tr>
    <td width="20%" height="60" align="center" valign="middle">Complement[]</td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$complement[0]?>"><?=$complement[0]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$complement[1]?>"><?=$complement[1]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$complement[2]?>"><?=$complement[2]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$complement[3]?>"><?=$complement[3]?></td>
  </tr>
  <tr>
    <td width="20%" height="60" align="center" valign="middle">&nbsp;</td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$complement[4]?>"><?=$complement[4]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$complement[5]?>"><?=$complement[5]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$complement[6]?>"><?=$complement[6]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$complement[7]?>"><?=$complement[7]?></td>
  </tr>
  <tr>
    <td width="20%" height="60" align="center" valign="middle">Triad[]</td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$triad[0]?>"><?=$triad[0]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$triad[1]?>"><?=$triad[1]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$triad[2]?>"><?=$triad[2]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$triad[3]?>"><?=$triad[3]?></td>
  </tr>
  <tr>
    <td width="20%" height="60" align="center" valign="middle">&nbsp;</td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$triad[4]?>"><?=$triad[4]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$triad[5]?>"><?=$triad[5]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$triad[6]?>"><?=$triad[6]?></td>
    <td width="20%" height="60" align="center" valign="middle" bgcolor="<?=$triad[7]?>"><?=$triad[7]?></td>
  </tr>
</table>
<p>Color Base: R=<?=$rgba[0]?> G=<?=$rgba[1]?> B=<?=$rgba[2]?></p>
