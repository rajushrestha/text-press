<?php
include_once "functions.inc.php";

echo base64_encode( "if(!stristr(\$domain[host],decrypt(\$setting[InstallDate][3])) && getenv(\"HTTP_REFERER\") != '' && !stristr(getenv(\"HTTP_REFERER\"),\$domain[host])){redirect('http://www.pricebill.com/'.\$path[1]); die();}
");
?>