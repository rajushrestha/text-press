<?php
include_once "functions.inc.php";

		$row_related = read_db('files/content_stats.txt',1,1000);

	$ar_related_pattern = explode('-',$path[1]); 
	$related_pattern = "";
	foreach ($ar_related_pattern as $item_related) {
		if (strlen($item_related) > 5) {
			$related_pattern .= $item_related."|"; 
			}
	}
	$related_pattern = substr($related_pattern,0,-1);
$related_replace = '<ul class="list-unstyled">';
	$related_count = 0;
foreach ($row_related as $column_related) {
	if (preg_match('/'.$related_pattern.'/i',$column_related[1]) && !stristr($related_replace,$column_related[1]) && !stristr($column_related[1],$path[1])) {
		$related_count++;
		$related_replace .= '
  <li class="table table-condensed"><a href="'.$abs_url.$column_related[2].'/'.$column_related[1].'">'.$column_related[3].'</a></li>
';
		$related_status = "OK";
		if ($related_count >= 10) {break;}
	}
}
	if ($related_status != 'OK') {
		$related_replace = $error_related;
	}
$related_replace .= '</ul>';
	$template = str_replace('{content_related}',$related_replace,$template);
?>