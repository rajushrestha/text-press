<?php 
include_once "functions.inc.php";

							$row_history = read_db('files/login_history.txt',1,2);
							foreach ($row_history as $column_history) {
	$history[1] = $column_history[1];
	$history[2] = $column_history[2];	//login
	$history[3] = date('Y-m-d H:i:s');	//logout
	$history[4] = $column_history[4];
	replace_db('files/login_history.txt',$history,$column_history[2]);

								break;
							}
	setcookie('username', NULL, -1);

    redirect($abs_url."?q=logout" );

?>