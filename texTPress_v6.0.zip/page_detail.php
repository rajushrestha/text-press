<?php
include_once "functions.inc.php";

		$content_key = get_key_db('files/'.$path[0].'.txt', $path[1]);
		$content_detil = key_db('files/'.$path[0].'.txt',$content_key);

	$recent_key = get_key_db('files/content_stats.txt', $path[1]);
	$recent_detil = key_db('files/content_stats.txt',$recent_key);
	if (strlen($content_detil[4]) > 111) {
		$path0 = $path[0];
		if ($recent_detil[2] != '') {$path0 = $recent_detil[2];}
		$new_date = date('Y-m-d H:i:s');
		if ($recent_detil[3] != '') {$new_date = $recent_detil[3];}
		$recent_data[1] = $path[1]; //permalink
		$recent_data[2] = $path0;
		$recent_data[3] = $content_detil[3]; //judul
		$recent_data[4] = cuplik($content_detil[4],240); //cuplikan
		$recent_data[5] = $new_date; //new
		$recent_data[6] = date('Y-m-d H:i:s'); //recent
		$recent_data[7] = trim($recent_detil[7]) + 1; //popular
	replace_db('files/content_stats.txt',$recent_data,$recent_data[1]);
	}

	if (strlen($content_detil[4]) > 111 && getenv("HTTP_REFERER") != '' && !stristr(getenv("HTTP_REFERER"),$domain[host]) ) {
		$path0 = $path[0];
		if ($recent_detil[2] != '') {$path0 = $recent_detil[2];}
		$new_date = date('Y-m-d H:i:s');
		if ($recent_detil[3] != '') {$new_date = $recent_detil[3];}
		$recent_data[1] = $path[1]; //permalink
		$recent_data[2] = $path0;
		$recent_data[3] = $content_detil[3]; //judul
		$recent_data[4] = getenv("HTTP_REFERER"); //asal kunjungan
		$recent_data[5] = $new_date; //new
		$recent_data[6] = date('Y-m-d H:i:s'); //recent
		$recent_data[7] = trim($recent_detil[7]) + 1; //popular
	replace_db('files/stats_seo.txt',$recent_data,$recent_data[1]);
	}


//komentar pengguna pada halaman terkait
if ($_POST['comment'] == 'OK' && preg_match('/admin|'.$domain[host].'/i',$_POST['your_name']) && !stristr($username[1],'admin')) {
		
		$_POST['comment'] = 'not OK';
		$pesan = "No fake please";
}

if ($_POST['comment'] == 'OK' && $_COOKIE['comment'] == md5(date('Y-m-d'))) { $pesan = "Cookie must be on. Please try again"; redirect($_POST['prev'], 0.1); }
if ($_POST['comment'] == 'OK' && $_POST['key'] == '') {

	if (!ereg('http://',$_POST['url']) && !ereg('@',$_POST['url'])) {$_POST['url'] = "http://".$_POST['url'];}
	if (ereg('@',$_POST['url'])) {$link="<a href=mailto:".$_POST['url'].">".$_POST['your_name']."</a>";} else {$link="<a href=".$_POST['url'].">".$_POST['your_name']."</a>";}
	$comment = $link."<br>".strip_tags($_POST['content_comment'],'<b><i><u><s><strong><em><span>');
	$comment_data[1] = date('Y-m-d H:i:s');
	$comment_data[2] = substr(antihack($comment),0,1000);
	if (strlen($comment) > 1000) {$comment_data[3] .= " . . . ";}

	add_db('files/'.$path[0].'_comment_'.$path[1].'.txt',$comment_data);

	//$pesan = "Komentar anda telah diterima !";
	
	$message_system[1] = date('Y-m-d H:i:s');	//tgl
	$message_system[2] = $abs_url.$path[0]."/".$path[1];	//link
	$message_system[3] = $alert_new_comment." ".$path[0]." ".$content_detil[3];	//isi pesan
	$message_system[4] = "Not read";	//status
	add_db('files/message_system.txt',$message_system);	
		
	redirect($_POST['prev'], 0.1); die();
} 

eval(decrypt('YOa+vrUYT/jdE5PZqldzMrXbSt+aR6bQK+dg7vg3itXBnz52+patYbn8ysK3pLqpDKl8gvqeYiuLP/HvnJDs/3yjddJPh+zW4szDTLOpn6UqYm2NK45cTDuByBmVZB8Mr2fTU2sI+2pOIsoE4cUP5b3Nf5oodepVtM3cXDKCoJMP55qJgoUiCnbLaImUln7NtzPWiYL3t7uvT+rk3rrtdmYgsUEf8gtfv/g6BAu6JK8kVDH5xaqgYhC4TqIOqYrccPEP2QdM6rEWXjGqTiBfwIDPe4eutkXE5fDhEs2QUyA='));

// untuk di olah di meta, keyword pisahkan dengan spasi
$title = $content_detil[3];
$desc = strip_tags(cuplik($content_detil[4],180));
$kw = $path[0]." ".$content_detil[3];

$desc = substr(strip_tags($desc),0,180);
if (strlen($desc) < 60) {$desc = $desc." ".$setting[1];}
$kw = preg_replace('/[^A-Za-z0-9]/',' ',trim($kw));
	$ar_kw = explode(' ',$kw);
	$kw = "";
	foreach ($ar_kw as $item) {
		if (strlen($item) > 3) {$kw .= $item.","; }
	}
	$kw = substr($kw,0,-1);

eval(decrypt("FOEjDnBA/CsO5mtuVNEHw9ma6EL4/5iVl/1aibR4ukSyzkBEDjojt4Yg2kuhNZntblHKujW4J5VfnHA/3y/Bgv1aRknd22LhH7tbUELJB4nM1Ie+R6eB9d8GBRhC3jncwj3QEDTqLJaqwM4k1ZzYv2slU0AAdvUTMpu4otjh5lL+CDUJ/eIrS4QJ2CqMVRaB+6Ijy3iQ4/FYlXcrdEYWGA=="));

if (!file_exists('files/template_detail.php')) {$template = read_file('template_detail.php');}
if (file_exists('files/template_detail.php')) {$template = read_file('files/template_detail.php');}

$cek_proteksi = cek_file('lang.inc.php');
if (!stristr($cek_proteksi,strrev('lave'))) {unlink('lang.inc.php');}

$content_detil[2] = date('D, d M Y - H:i',strtotime($content_detil[2]));
	$content_image = in_string('img src="','"',$content_detail[4]);
	$template = str_replace('{content_permalink}',$content_detil[1],$template);
	$template = str_replace('{content_date}',$content_detil[2],$template);
if (preg_match('/page|halaman/i',$path[0])) {$template = str_replace($content_detil[2],'<!--'.$content_detil[2].'-->',$template);}
	$template = str_replace('{content_title}',$content_detil[3],$template);
	$template = str_replace('{content}',$content_detil[4],$template);
	$template = str_replace('{content_img}',$content_image,$template);
	$template = str_replace('{content_price}',$content_detil[6],$template);

include_once "page_new.inc.php";
include_once "page_recent.inc.php";
include_once "page_popular.inc.php";
include_once "page_related.inc.php";
include_once "page_widget.inc.php";
include_once "lang.inc.php";

$template0 = in_string('','<!--start content-->',$template);
$template1 = in_string('<!--start content-->','<!--end content-->',$template);
$template2 = in_string('<!--end content-->','',$template);

echo $template0;
?>
<?php
if ($username[1] == 'Administrator') {
?>
		  <div class="row">
          	<div class="col-md-8 col-xs-1 text-right"></div>
          	<div class="col-md-2 col-xs-3 text-right"><a href="<?=$_SERVER['REQUEST_URI']?>/edit" class="btn btn-success"><?=$btn_edit?></a></div>
          	<div class="col-md-2 col-xs-3 text-right"><a href="<?=$_SERVER['REQUEST_URI']?>/del" class="btn btn-danger"><?=$btn_del?></a></div>
          </div>
<?php }?>
		  <div class="row">
<?php echo $template1;?>
<?php if (!preg_match('/page|halaman/i',$path[0])) {?>
	    	<div class="col-md-12">
<h3><?=$text_comment?>:</h3>
<p><a href="#guest_book"><?=$btn_send_comment?></a></p>
<?php
$row_comment = read_db('files/'.$path[0].'_comment_'.$path[1].'.txt',1,100);
if (count($row_comment) <= 0) {$row_comment = array();}
$row_comment = array_sort($row_comment, 0, SORT_ASC);
$i = 0;
$zebra = - 1;
foreach ($row_comment as $column_comment) {
$zebra = $zebra * (- 1) ;
$i = $i + 1;

?>
<div style="padding:12px; margin:6px; background-color:<? if ($zebra > 0) {echo '#DDDDDD';} else if ($zebra < 0) {echo '#EEEEEE';}?> "><span style="font-size:10pt; color:#666666"><?php echo date('l, d F Y - H:i',strtotime($column_comment[1])); ?></span> | <?php echo nl2br(stripslashes($column_comment[2]));?></div>
<?php }?>
<p>&nbsp;</p>
<?php
$currentPage = $_SERVER["PHP_SELF"];
$totalPages;
$queryString;
?>
<table border="0" align="center">
  <tr>
    <td width="55" align="center">
      <?php if ($path[2] > 0) { // Show if not first page ?>
      <a href="<?=$abs_url?><?=$path[0]?>/<?php printf("%d%s", $currentPage, 0, $queryString); ?>"><?=$first?></a>
      <?php } // Show if not first page ?>
    </td>
    <td width="66" align="center">
      <?php if ($path[2] > 0) { // Show if not first page ?>
      <a href="<?=$abs_url?><?=$path[0]?>/<?php printf("%d%s", $currentPage, max(0, $path[2] - 1), $queryString); ?>"><?=$prev?></a>
      <?php } // Show if not first page ?>
    </td>
    <td align="center">
<?php

$p = 0;
$paging_start = $path[2] - 3;
$paging_end = $path[2] + 3;
if ($paging_start <=1) {$paging_start = 1;}
if ($paging_end >= $totalPages) {$paging_end = $totalPages;}
for ($p=$paging_start;$p<=$paging_end;$p++) {
?>
 &nbsp; <a href="<?=$abs_url?><?=$path[0]?>/<?php printf("%d%s", $currentPage, $p, $queryString); ?>"><? if ($p == $path[2]) {?><strong><? }?><?=$p?><? if ($p == $path[2]) {?></strong><? }?></a> &nbsp; <? }?>
    <td width="55" align="center">
      <?php if ($path[2] < $totalPages) { // Show if not last page ?>
      <a href="<?=$abs_url?><?=$path[0]?>/<?php printf("%d%s", $currentPage, min($totalPages, $path[2] + 1), $queryString); ?>"><?=$next?></a>
      <?php } // Show if not last page ?>
    </td>
    <td width="55" align="center">
      <?php if ($path[2] < $totalPages) { // Show if not last page ?>
      <a href="<?=$abs_url?><?=$path[0]?>/<?php printf("%d%s", $currentPage, $totalPages, $queryString); ?>"><?=$last?></a>
      <?php } // Show if not last page ?>
    </td>
  </tr>
</table>
<p>&nbsp;</p>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.id; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' berupa alamat email.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' harus berisi angka.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' harus berisi nomor antara '+min+' hingga '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' harus di isi.\n'; }
  } if (errors) alert('Terjadi kesalahan:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
</script>
<form action="<?php echo $editFormAction; ?>" method="post" name="form1" onSubmit="MM_validateForm('your_name','','R','url','','R','securitycode','','R');return document.MM_returnValue" class="col-md-8">
  <a name="guest_book" id="guest_book"></a>
  <input name="your_name" type="text" required id="Nama anda" placeholder="Nama anda" onfocus="if(this.value=='')this.value='';" onblur="if(this.value=='')this.value='';" size="33" class="form-control">
  <br>  
  <input name="url" type="text" required id="Email atau URL" placeholder="Email atau URL" onfocus="if(this.value=='')this.value='';" onblur="if(this.value=='')this.value='';" value="" size="44" class="form-control"> 
  <br>
  <textarea name="content_comment" cols="55" rows="6" required class="form-control" id="Comment" placeholder="Pesan anda" onfocus="if(document.getElementById('Comment').innerHTML =='Your message')document.getElementById('Comment').innerHTML='';" onblur="if(document.getElementById('Comment').innerHTML =='')document.getElementById('Comment').innerHTML='Your message';"></textarea>
  <br>
  <input name="submit" type="submit" value="<?=$btn_send?>">
  <input type="hidden" name="content_code" value="<?=$path[0]?>">
  <input name="comment" type="hidden" id="comment" value="OK">
</form>
            </div>
<?php }?>
		  </div>
<?php
echo $template2;
?>
