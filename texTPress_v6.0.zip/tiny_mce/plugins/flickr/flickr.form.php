<?
if ($_POST['Submit'] != '') {
$flickr_title = $_POST['title'];
$flickr_desc = $_POST['desc'];
include_once"flickr.add.php";
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Upload foto ke flickr</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?=$flickr[thumbnail][source]?>
<form action="" method="post" enctype="multipart/form-data" name="form1">
<p>
  Judul foto:<br>
  <input name="title" type="text" id="title" size="33">
</p>
<p>
  Keterangan foto:<br>
  <textarea name="desc" cols="55" rows="4" id="desc"></textarea>
</p>
  File foto:<br>
  <input type="file" name="file">
  <input type="submit" name="Submit" value="Submit">
</form>
</body>
</html>