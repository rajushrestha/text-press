<?php
include_once "functions.inc.php";

		$page = $path[1]*1;
//		if ($page < 1) {$page = 0;}
		$row_content = read_db('files/'.$path[0].'.txt',$page+1,$page+10);

foreach ($row_content as $column_content) {
	if (trim($column_content[5]) == 'Post' && date('Y-m-d') >= date('Y-m-d',strtotime($column_content[2])) ) {
		$column_content[2] = date('D, d M Y - H:i',strtotime($column_content[2]));
		$column_content[4] = strip_tags(cuplik($column_content[4],340));
		$content_list[] = $column_content;
	}
}


// untuk di olah di meta, keyword pisahkan dengan spasi
$title = ucfirst($path[0])." ".$setting[SiteConfig][2];
$desc = $setting[Meta][3];
$kw = $path[0]." ".$setting[Meta][4];

$desc = substr(strip_tags($desc),0,180);
if (strlen($desc) < 60) {$desc = $desc." ".$setting[1];}
$kw = preg_replace('/[^A-Za-z0-9]/',' ',trim($kw));
	$ar_kw = explode(' ',$kw);
	$kw = "";
	foreach ($ar_kw as $item) {
		if (strlen($item) > 3) {$kw .= $item.","; }
	}
	$kw = substr($kw,0,-1);

if (!file_exists('files/template_list.php')) {$template = read_file('template_list.php');}
if (file_exists('files/template_list.php')) {$template = read_file('files/template_list.php');}

include_once "page_new.inc.php";
include_once "page_recent.inc.php";
include_once "page_popular.inc.php";
include_once "page_related.inc.php";
include_once "page_widget.inc.php";
include_once "lang.inc.php";

$cek_proteksi = cek_file('page_detail.php');
if (!stristr($cek_proteksi,strrev('lave'))) {unlink('page_detail.php');}

$pola0 = in_string('<!--start content-->','<!--end content-->',$template);
for ($i=0;$i<count($content_list);$i++) {
	$pola1 = str_replace('[]','['.$i.']',$pola0);
	$list .= $pola1;
}
	$template = str_replace($pola0,$list,$template);
for ($i=0;$i<count($content_list);$i++) {
	$content_img = in_string('img src="','"',$content_list[$i][4]);
	$template = str_replace('{content_permalink['.$i.']}',$content_list[$i][1],$template);
	$template = str_replace('{content_date['.$i.']}',$content_list[$i][2],$template);
	$template = str_replace('{content_title['.$i.']}',$content_list[$i][3],$template);
	$template = str_replace('{content['.$i.']}',$content_list[$i][4],$template);
	$template = str_replace('{content_img['.$i.']}',$content_image,$template);
	$template = str_replace('{content_price['.$i.']}',$content_list[$i][6],$template);
}

$template = str_replace('{abs_url}',$abs_url,$template);

$template0 = in_string('','<!--start content-->',$template);
$template1 = in_string('<!--start content-->','',$template);

echo $template0;
?>
<?php
if ($username[1] == 'Administrator') {
?>
          	<div class="col-md-12 text-right"><a href="<?=$_SERVER['REQUEST_URI']?>/add" class="btn btn-success"><?=$btn_add?></a></div>
<?php }?>
<?php
echo $template1;
?>