<?php include_once "ijin_user.inc.php";?>
<?php
include_once "functions.inc.php";

		$user_key = get_key_db('files/user.txt', $username[2]);
		$user_detil = key_db('files/user.txt',$user_key);

if ($_POST['install'] == 'admin') {

$install_data[1] = $user_detil[1] ;
$install_data[2] = $user_detil[2] ;
$install_data[3] = md5("{[".$_POST['password']."]}") ;

$install_data[0] = $user_detil[0] ;
edit_db('files/user.txt',$install_data); 

$pesan = $alert_save; 
}

// untuk di olah di meta, keyword pisahkan dengan spasi
$title = $content_detil[3];
$desc = strip_tags(cuplik($content_detil[4],180));
$kw = $path[0]." ".$content_detil[3];

$desc = substr(strip_tags($desc),0,180);
if (strlen($desc) < 60) {$desc = $desc." ".$setting[1];}
$kw = preg_replace('/[^A-Za-z0-9]/',' ',trim($kw));
	$ar_kw = explode(' ',$kw);
	$kw = "";
	foreach ($ar_kw as $item) {
		if (strlen($item) > 3) {$kw .= $item.","; }
	}
	$kw = substr($kw,0,-1);

if (!file_exists('files/template_detail.php')) {$template = read_file('template_detail.php');}
if (file_exists('files/template_detail.php')) {$template = read_file('files/template_detail.php');}

if (!stristr($template,'jquery')) {$template = str_replace("</body>","<script src=\"http://localhost/texTPress/js/jquery.js\"></script>
</body>",$template);}
if (!stristr($template,'bootstrap')) {$template = str_replace("</head>","<link href=\"".$abs_url."css/bootstrap.css\" rel=\"stylesheet\">
	</head>",$template);
	$template = str_replace("</body>","<script src=\"".$abs_url."js/bootstrap.js\"></script>
	</body>",$template);
	}
if (!stristr($template,'masonry')) {$template = str_replace("</body>","<script src=\"".$abs_url."js/masonry.min.js\"></script>
</body>",$template);}

include_once "page_new.inc.php";
include_once "page_recent.inc.php";
include_once "page_popular.inc.php";
include_once "page_related.inc.php";
include_once "page_widget.inc.php";
include_once "lang.inc.php";

$template0 = in_string('','<!--start content-->',$template);
$template1 = in_string('<!--start content-->','<!--end content-->',$template);
$template2 = in_string('<!--end content-->','',$template);

echo $template0;
?>
<p>&nbsp;</p>
<div class="row">
	<div class="col-md-7">
    	<h3><?=$text_change_password?></h3>
                  <p><?=$text_activate?></p>
<form action="<?php echo $ormAction; ?>" method="post" name="form1">
    <table align="center" class="table table-condensed">
      <tr valign="baseline">
        <td width="33%" align="right" nowrap>Email:</td>
        <td><?=$user_detil[2]?></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">Password:</td>
        <td><input name="password" type="text" required id="Password" value="" size="33"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">&nbsp;</td>
        <td><input type="submit" value="<?=$btn_save?>"></td>
      </tr>
    </table>
    <input type="hidden" name="install" value="admin">
</form>
                  <p>&nbsp;</p>
	</div>
</div>
<?php
echo $template2;
?>
<?php 
if ($pesan != '') {
	echo "<script type=\"text/javascript\">alert('".$pesan."');</script>";
	$pesan = '';
	redirect($_SERVER['REQUEST_URI'], 0.1);
}
?>
