<?php
include_once "functions.inc.php";

//eval('aWYgKCFzdHJpc3RyKCRfU0VSVkVSWydIVFRQX0hPU1QnXSwncXIuZGVzYWluLmNvLmlkJykgJiYgIXN0cmlzdHIoJF9TRVJWRVJbJ0hUVFBfSE9TVCddLCdsb2NhbGhvc3QnKSkge2luY2x1ZGUgIjQwNC5waHAiOyBkaWUoKTt9');

		$template_key = get_key_db('files/template.tmp.txt', $path[3]);
		$template_detil = key_db('files/template.tmp.txt',$template_key);

// untuk di olah di meta, keyword pisahkan dengan spasi
$title = "texTPress CMS";
$desc = "texTPress is a web application to publish the information through the website which is created by php using text files as data storage. texTPress is built without the need for setting the database. Once you finish putting the files to the server, this application can be executed directly.";
$kw = "textpress,cms,agc,auto blog";

$desc = substr(strip_tags($desc),0,180);
if (strlen($desc) < 60) {$desc = $desc." ".$setting[1];}
$kw = preg_replace('/[^A-Za-z0-9]/',' ',trim($kw));
	$ar_kw = explode(' ',$kw);
	$kw = "";
	foreach ($ar_kw as $item) {
		if (strlen($item) > 3) {$kw .= $item.","; }
	}
	$kw = substr($kw,0,-1);

$template = read_file('template_textpress.php');

include_once "lang.inc.php";

$top_menu = in_string('<div class="navbar-collapse collapse navbar-right">','</div>',$template);
if ($path[4] == 'detail') {$menu_detil = ' class="active"';}
if ($path[4] == 'list') {$menu_list = ' class="active"';}
if ($path[4] == 'home') {$menu_home = ' class="active"';}
$new_menu = '			  <ul class="nav navbar-nav">
					<li><a href="#">'.$template_detil[3].'</a></li>
					<li'.$menu_detil.'><a href="#">Detail &raquo;</a></li>
					<li'.$menu_list.'><a href="#">List &raquo;</a></li>
					<li'.$menu_home.'><a href="#">Home &raquo;</a></li>
					<li><a href="#">Finish !</a></li>
			  </ul>
';
$template = str_replace($top_menu,$new_menu,$template);

$template0 = in_string('','<!--start content-->',$template);
$template1 = in_string('<!--start content-->','<!--end content-->',$template);
$template2 = in_string('<!--end content-->','',$template);

$script_template = $template_detil[4];
$script_template = urlencode($script_template);

echo $template0;
include "wysiwyg.inc.php";
?>
<form id="form1" name="form1" method="post">
  <p>
    <textarea name="template" cols="111" rows="22" id="template"><?=$script_template;?></textarea>
  </p>
  <p>
    <input type="submit" name="submit" id="submit" value="<?=$btn_save?>">
  </p>
</form>
<?php
echo $template2;
?>
