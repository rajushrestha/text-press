<?php
include_once "functions.inc.php";

		$row_popular = read_db('files/content_stats.txt',1,100);
		$row_popular = array_sort($row_popular,7,SORT_DESC);

$replace_popular = '<ul class="list-unstyled">';
$count_popular = 0;
foreach ($row_popular as $column_popular) {
	if (strlen($column_popular[3]) > 11 && !stristr($replace_popular,$column_popular[1]) && !stristr($column_popular[1],$path[1])) {
			$count_popular++;
			$replace_popular .= '
	  <li class="table table-condensed"><a href="'.$abs_url.$column_popular[2].'/'.$column_popular[1].'">'.$column_popular[3].'</a></li>
	';
		if ($count_popular >= 5) {break;}
	}
}
	if ($status_popular != 'OK') {
		$status_popular = $error_popular;
	}
$replace_popular .= '</ul>';
	$template = str_replace('{content_popular}',$replace_popular,$template);
?>