<?php include_once "ijin_user.inc.php";?>
<?php
include_once "functions.inc.php";

if ($_POST['simpan'] == 'page') {
	$permalink = strtolower($_POST['judul']);
	$permalink = preg_replace('/[^0-9a-zA-Z]/',' ',$permalink);
	$permalink = preg_replace('/[^0-9a-zA-Z]/','-',trim($permalink));
	$content[1] = $permalink;
	$content[2] = $_POST['tgl'];
	$content[3] = $_POST['judul'];
	$content[4] = $_POST['isi'];
	$content[5] = $_POST['status'];
	$content[6] = $_POST['harga'];
	$content[7] = $_POST['note'];
	replace_db('files/'.$path[0].'.txt',$content,$content[1]);
	redirect($abs_url.$path[0].'/'.$permalink,0.1); die();
}

	$content_key = get_key_db('files/'.$path[0].'.txt', $path[1]);
	$content_detil = key_db('files/'.$path[0].'.txt',$content_key);

//eval('aWYgKCFzdHJpc3RyKCRfU0VSVkVSWydIVFRQX0hPU1QnXSwncXIuZGVzYWluLmNvLmlkJykgJiYgIXN0cmlzdHIoJF9TRVJWRVJbJ0hUVFBfSE9TVCddLCdsb2NhbGhvc3QnKSkge2luY2x1ZGUgIjQwNC5waHAiOyBkaWUoKTt9');

// untuk di olah di meta, keyword pisahkan dengan spasi
$title = $text_administration." ".$path[0].": ".$content_detil[3];
$desc = strip_tags(cuplik($content_detil[4],180));
$kw = $title;

$desc = substr(strip_tags($desc),0,180);
if (strlen($desc) < 60) {$desc = $desc." ".$setting[1];}
$kw = preg_replace('/[^A-Za-z0-9]/',' ',trim($kw));
	$ar_kw = explode(' ',$kw);
	$kw = "";
	foreach ($ar_kw as $item) {
		if (strlen($item) > 3) {$kw .= $item.","; }
	}
	$kw = substr($kw,0,-1);

if (!file_exists('files/template_detail.php')) {$template = read_file('template_detail.php');}
if (file_exists('files/template_detail.php')) {$template = read_file('files/template_detail.php');}

include_once "page_new.inc.php";
include_once "page_recent.inc.php";
include_once "page_popular.inc.php";
include_once "page_related.inc.php";
include_once "page_widget.inc.php";
include_once "lang.inc.php";

$template0 = in_string('','<!--start content-->',$template);
$template1 = in_string('<!--start content-->','<!--end content-->',$template);
$template2 = in_string('<!--end content-->','',$template);

if ($path[1] != '' && $path[2] == 'edit') {$content_detil[3] = ucfirst(str_replace('-',' ',$path[1]));}

echo $template0;
?>
<link href="<?=$abs_url?>css/bootstrap-datetimepicker.css" rel="stylesheet">
<?php include_once "wysiwyg.inc.php";?>
                	<h3><?=$administration?> <?=$path[0]?>: <?=$content_detil[3]?></h3>
                	<form action="" method="post">
                	  <table width="666" border="0" cellspacing="0" cellpadding="2" class="table table-condensed">
                	    <tr align="left" valign="top"<?php if (preg_match('/widget|halaman|page/i',$path[0])) {?> class="collapse"<?php }?>>
                	      <td><?=$text_date?></td>
                	      <td><input name="tgl" type="text" id="tgl" value="<?=date('Y-m-d H:i:s')?>" size="44" class="form-control form_datetime"></td>
              	      </tr>
                	    <tr align="left" valign="top">
                	      <td width="166"><?=$text_title?></td>
                	      <td width="492"><input name="judul" type="text" required class="form-control" id="judul" value="<?=$content_detil[3]?>" size="44"></td>
              	      </tr>
                	    <tr align="left" valign="top">
                	      <td><?=$text_content?></td>
                	      <td><textarea name="isi" cols="66" rows="6" id="isi"><?=$content_detil[4]?></textarea></td>
              	      </tr>
<?php if (preg_match('/shop|cart|product|toko|produk/i',$path[0])) {?>
                	    <tr align="left" valign="top">
                	      <td><?=$text_price?></td>
                	      <td><input name="harga" type="text" id="harga" value="<?=$content_detil[6]?>" size="44" class="form-control"></td>
              	      </tr>
<?php }?>
                	    <tr align="left" valign="top">
                	      <td>&nbsp;</td>
                	      <td><p>
<input name="status" type="radio" required id="Status_0" value="Post" <?php if(trim($content_detil[5]) == 'Post') {echo "checked";}?>>
               	            <?=$post?> 
               	            <input name="status" type="radio" required id="Status_1" value="Draft" <?php if(trim($content_detil[5]) == 'Draft') {echo "checked";}?>>
               	            <?=$draft?>                	        <br>
              	        </p></td>
              	      </tr>
                	    <tr align="left" valign="top">
                	      <td><?=$text_content_note?></td>
                	      <td><textarea name="note" cols="66" rows="6" id="note"><?=$content_detil[7]?></textarea>
                          <small class="text-muted"><?=$text_content_note_info?></small>
                          </td>
              	      </tr>
                	    <tr align="left" valign="top">
                	      <td>&nbsp;</td>
                	      <td><input type="submit" name="submit" id="submit" value="<?=$btn_save?>">
           	              <input name="simpan" type="hidden" id="simpan" value="page"></td>
              	      </tr>
              	      </table>
       	          </form>
<?php
echo $template2;
?>
    <script src="<?=$abs_url?>js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
    $(".form_datetime").datetimepicker({format: 'yyyy-mm-dd hh:ii'});
</script>
