<?php
include_once "functions.inc.php";

if ($_POST['email'] != '') {
	$cek_user = cek_file('files/user.txt');
	if (!stristr($cek_user,$_POST['email'])) {
		$pesan_lupa = $alert_email_not_registered;
	}
	if (stristr($cek_user,$_POST['email'])) {
		$user_key = get_key_db('files/user.txt', $_POST['email']);
		$user_data = key_db('files/user.txt',$user_key);
		$confirm = serialize($user_data);
		$crypt_confirm = base64_encode($confirm);

   // kirim email
   $domain = $_SERVER['HTTP_HOST'];
   $domain = str_replace('/','',$domain);
   $domain = str_replace('www.','',$domain);
   $url_konfirmasi = $abs_url."reset-password/".$crypt_confirm;
       // save and send notification email
      $emailbody = read_file('email_lupa_password.html');
      $emailbody = str_replace("{ip_user}",$_SERVER['REMOTE_ADDR'],$emailbody);
      $emailbody = str_replace("{site_url}",$domain,$emailbody);
      $emailbody = str_replace("{link_konfirmasi}",$url_konfirmasi,$emailbody);

$headers .= "From: QR Code Indonesia <'robot@".$domain."'>\n";
$headers .= "X-Sender: <'robot@".$domain."'>\n";
$headers .= "X-Mailer: PHP\n"; // mailer
$headers .= "X-Priority: 1\n"; // Urgent message!
$headers .= "Return-Path: <'cs@".$domain."'>\n";  // Return path for errors

// If you want to send html mail, uncomment the following line 
$headers .= "Content-Type: text/html; charset=iso-8859-1\n"; // Mime type

      mail($_POST['email'], "Konfirmasi reset password anda di ".$domain, $emailbody, $headers);
//      mail("fauzan@tetuku.com", "Pendaftaran ".$_POST['nama_perusahaan']." di ".$_SERVER['HTTP_HOST'], $emailbody, $headers);
//akhir kirim email	*/

		redirect($abs_url.'reset-password',0.1); die();
	}
}

// untuk di olah di meta, keyword pisahkan dengan spasi
$desc = $text_please_reset;
$kw = str_replace(' ',',',$desc);
?><!doctype html>
<html>
<meta charset="utf-8"><title>Reset password</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="{meta_description}" />
	<meta name="keywords" content="textpress,login" />
	<meta name="author" content="texTPress" />
  	
	<meta property="og:image" content="" />
	<meta property="og:url" content="" />
	<meta property="og:site_name" content="{meta_site_name}" />

<link rel="icon" href="<?=$abs_url?>favicon.png" type="image/x-icon" />
<link rel="shortcut icon" href="<?=$abs_url?>favicon.png" type="image/x-icon" />

    <link href="<?=$abs_url?>css/bootstrap.css" rel="stylesheet">
</head>

<body>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
<div class="container">
		  <div class="row">
		    	<div class="col-md-3">&nbsp;</div>
		    	<div class="col-md-6">
                <form action="<?=$abs_url?>" method="post" enctype="multipart/form-data" class="form-signin" role="form">
                <h2 class="form-signin-heading">Reset password</h2>
                <?=$text_please_reset?>
                <input name="email" type="email"  required class="form-control" id="email" placeholder="Email anda" size="33">
                <input name="submit" type="submit" class="btn btn-lg btn-primary btn-block" id="submit" value="Reset Password">
                </form>
                <p>&nbsp;</p>
                <?=$text_reset_note?>
                </div>
		    	<div class="col-md-3">&nbsp;</div>
		  </div>
</div><!--/.container--> 
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
<?php 
if ($pesan_lupa != '') {
	echo "<script type=\"text/javascript\">
	var answer = confirm('".$pesan_lupa."')
	if (answer){
		window.location = \"".$abs_url."signup"."\";
	}
	else{
		exit();
	}
</script>";
	$pesan_lupa = '';
}

if ($pesan != '') {
	echo "<script type=\"text/javascript\">alert('".$pesan."');</script>";
	$pesan = '';
}
?>
</body>
</html>
