<?php

if (stristr($template,'{widget')) {
	$ar_widget = explode("{widget_content",$template);
			$row_widget = read_db('files/widget.txt',1,100);
			foreach ($row_widget as $column_widget) {
				$widget_detil[$column_widget[1]] = $column_widget;
			}
	$widget_no = 0;
	foreach ($ar_widget as $widget) {
		if ($widget_no > 0) {
			$nama_widget = in_string('_','}',$widget);				
				if ($widget_detil[$nama_widget][4] == '') {$widget_detil[$nama_widget][4] = $error_widget;}
			$template = str_replace('{widget_date_'.$nama_widget.'}',date('D, d M Y - H:i',strtotime($widget_detil[$nama_widget][5])),$template);
			$template = str_replace('{widget_title_'.$nama_widget.'}',$widget_detil[$nama_widget][3],$template);
			$widget_content = cuplik($widget_detil[$nama_widget][4],555);
			if (stristr($widget_content,'[...]') ) {$widget_content = str_replace('[...]','',$widget_content); $widget_content = str_replace('<br />','',$widget_content); }
			if ($_COOKIE['username'] != '') {$widget_content = $widget_content.' <a href="'.$abs_url.'widget/'.$nama_widget.'/edit">[+]</a>';}					
			$template = str_replace('{widget_content_'.$nama_widget.'}',$widget_content,$template);
			$template = str_replace('{widget_permalink_'.$nama_widget.'}',$widget_detil[$nama_widget][1],$template);
			}
		$widget_no++;
	}
}

?>