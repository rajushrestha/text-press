
			  <ul class="nav navbar-nav">
			    <li class="dropdown active"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Admin Panel<b class="caret"></b></a>
                   <ul class="dropdown-menu">
			        <li><a href="{abs_url}panel">Panel Home</a></li>
			        <li class="divider"></li>
			        <li class="dropdown-header">Site Setting</li>
			        <li><a href="{abs_url}change-template">Change Template</a></li>
			        <li><a href="{abs_url}meta-tags">Meta Tags</a></li>
			        <li class="divider"></li>
			        <li class="dropdown-header">Personal Setting</li>
			        <li><a href="{abs_url}change-password">Change Password</a></li>
			        <li><a href="{abs_url}logout">Logout</a></li>
		          </ul>
                </li>
		      </ul>
