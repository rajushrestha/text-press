<?php
include_once "functions.inc.php";

//eval('aWYgKCFzdHJpc3RyKCRfU0VSVkVSWydIVFRQX0hPU1QnXSwncXIuZGVzYWluLmNvLmlkJykgJiYgIXN0cmlzdHIoJF9TRVJWRVJbJ0hUVFBfSE9TVCddLCdsb2NhbGhvc3QnKSkge2luY2x1ZGUgIjQwNC5waHAiOyBkaWUoKTt9');

// untuk di olah di meta, keyword pisahkan dengan spasi
$title = "texTPress CMS";
$desc = "texTPress is a web application to publish the information through the website which is created by php using text files as data storage. texTPress is built without the need for setting the database. Once you finish putting the files to the server, this application can be executed directly.";
$kw = "textpress,cms,agc,auto blog";

$desc = substr(strip_tags($desc),0,180);
if (strlen($desc) < 60) {$desc = $desc." ".$setting[1];}
$kw = preg_replace('/[^A-Za-z0-9]/',' ',trim($kw));
	$ar_kw = explode(' ',$kw);
	$kw = "";
	foreach ($ar_kw as $item) {
		if (strlen($item) > 3) {$kw .= $item.","; }
	}
	$kw = substr($kw,0,-1);

$template = read_file('template_textpress.php');

include_once "lang.inc.php";

$template0 = in_string('','<!--start content-->',$template);
$template1 = in_string('<!--start content-->','<!--end content-->',$template);
$template2 = in_string('<!--end content-->','',$template);

echo $template0;
?>
                  <div class="row">
                    <div class="col-md-12 text-center jumbotron">
<?php if (strlen($setting[InstallDate][3]) > 11) {?>
                <?php if ($lang == 'id') {?>Lisensi untuk: <?php }?><?php if ($lang == 'en') {?>
                License for: 
                <?php }?><?php echo decrypt($setting[InstallDate][3]);?>
<?php }?>
                <br />
                        <?php if ($lang == 'id') {?>Anda menggunakan<?php }?><?php if ($lang == 'en') {?>You are using<?php }?> <? 
                $versi_skr = read_file('versi_textpress.txt'); 
                $versi_baru = access_url('http://text-press.googlecode.com/svn/versi_textpress.txt');
                $num_skr = preg_replace('/[^0-9.]/', '',$versi_skr);
                $num_baru = preg_replace('/[^0-9.]/', '',$versi_baru);
                echo "<a href=http://text-press.googlecode.com/svn/textpress_v".$num_skr.".zip>".$versi_skr."</a>";
                ?> (<?
                if ($num_skr >= $num_baru && $lang == 'id') {echo "terbaru";}
                if ($num_skr >= $num_baru && $lang == 'en') {echo "new";}
                if ($num_skr < $num_baru && $lang == 'id') {echo "versi terbaru: <a href=http://text-press.googlecode.com/svn/textpress_v".$num_baru.".zip>".$versi_baru."</a>";}
                if ($num_skr < $num_baru && $lang == 'en') {echo "new version: <a href=http://text-press.googlecode.com/svn/textpress_v".$num_baru.".zip>".$versi_baru."</a>";}
                        ?>)        
<?php if (strlen($setting[InstallDate][3]) < 11) {?>
				<?php if ($lang == 'id') {?>Versi Coba<?php }?><?php if ($lang == 'en') {?>Trial Version<?php }?>
<?php }?>
                    </div>
                  </div>
				  <div class="row">
                  	<div class="col-md-3">
                      <h2>About texTPress</h2>
                      <p>texTPress is a web application to publish the information through the website which is created by php using text files as data storage. texTPress is built without the need for setting the database. Once you finish putting the files to the server, this application can be executed directly. </p>
                      <p>&nbsp;</p>
                      <h3>Download texTPress</h3>
                      <p>You can try texTPress for free with the internet or run it on localhost. Please download at the following address: 
                        <br>
                      <a href="http://text-press.googlecode.com" target="_blank">                      http://text-press.googlecode.com</a></p>
                      <p>&nbsp;</p>
                      <h3>texTPress Support</h3>
                      <p>Do you need my services? Please contact me via: <br>
                        <?=$text_textpress_contact?>
                        <br>
                      I also serve your needs through the cloud-sourcing website. Please let me know the url service for design and php programming</p>
                      <p>&nbsp;</p>
                  	</div>
                    <div class="col-md-9">
                      <div class="row js-masonry">
                        <div class="col-md-6">
                         	<h3>Easy Design</h3>
                         	<p> texTPress lets you create professional quality sites from scratch, but if you want a helping hand, or if you’re new to building a web site, you can choose to use one of the beautiful templates that are included with the software.</p>
                         	<p>Whether you’re looking for a stylish template or something that is highly graphical there’s sure to be something to meet your needs.</p>
                        </div>
                        <div class="col-md-6">
                         	<h3>User friendly</h3>
                         	<p>Installation is the first point of contact for users, so texTPress had better be a friendly process. It has simplicity of installation process, update and remove content.  texTPress has primary purpose is to make an end user's job easier.</p>
                            <p>textpress has a structure and design that is easy to understand. users to easily update the page as easy as searching the web page. Its allows you to organize your site into pages and folders in the backend that dynamically update your menus.</p>
                        </div>
                        <div class="col-md-6">
                            <h3>Unsaturated market</h3>
                            <p>The number of people who want go online is much greater than the number of website that exist. Seize this opportunity to be one of the first designers to sell to this new market!</p>
                        </div>
                        <div class="col-md-6">
                            <h3>Responsive design</h3>
                            <p>Years ago having a website was optional. Today it's a given. Customers are increasingly using their mobile devices to visit your website.</p>
                            <p>A responsive website changes its appearance and layout based on the size of the screen the website is displayed on. Responsive sites can be designed to make the text on the page larger and easier to read on smaller screens. They can also be configured to make the buttons on the phone's screen easier to press. More sophisticated ways of using responsive design on a mobile device include: formatting the website to hide or present entirely different information, radically changing the graphics and colors, or even reducing the site to emphasize just its most important piece.</p>
                        </div>
                        <div class="col-md-6">
                            <h3>SEO Standard</h3>
                            <p>A lot of developers can have a bit of a blind-spot when it comes to SEO. While some on-site SEO features almost always come as standard now (ability to edit meta tags, image alt properties, etc.), there are some important areas under the hood that often get missed.</p>
                            <p>texTPress has a suite of integrated SEO tools that ensure you get the most out of your website with improved discoverability in search engine results. It has ability to make sure your page implements semantic URLs on your site and gives you control over each page's URL. Input title tags, meta descriptions, meta keywords and header tags are automatically defined</p>
                        </div>
                      </div>
                    </div>
				  <p>&nbsp;</p>
                  </div>
<?php
echo $template2;
?>
