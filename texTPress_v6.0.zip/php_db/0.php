<?php $entries = array(
array('0','16777215','ZZ'),
);