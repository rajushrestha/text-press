<?php
include_once "functions.inc.php";

		$row_recent = read_db('files/content_stats.txt',1,100);
		$row_recent = array_sort($row_recent,6,SORT_DESC);

$replace_recent = '<ul class="list-unstyled">';
$count_recent = 0;
foreach ($row_recent as $column_recent) {
	if (strlen($column_recent[3]) > 11 && !stristr($replace_recent,$column_recent[1]) && !stristr($column_recent[1],$path[1])) {
			$count_recent++;
			$replace_recent .= '
	  <li class="table table-condensed"><a href="'.$abs_url.$column_recent[2].'/'.$column_recent[1].'">'.$column_recent[3].'</a></li>
	';
		if ($count_recent >= 5) {break;}
	}
}
	if ($status_recent != 'OK') {
		$status_recent = $error_recent;
	}
$replace_recent .= '</ul>';
	$template = str_replace('{content_recent}',$replace_recent,$template);
?>