<?php
include_once "functions.inc.php";

//eval('aWYgKCFzdHJpc3RyKCRfU0VSVkVSWydIVFRQX0hPU1QnXSwncXIuZGVzYWluLmNvLmlkJykgJiYgIXN0cmlzdHIoJF9TRVJWRVJbJ0hUVFBfSE9TVCddLCdsb2NhbGhvc3QnKSkge2luY2x1ZGUgIjQwNC5waHAiOyBkaWUoKTt9');

// untuk di olah di meta, keyword pisahkan dengan spasi
$title = "texTPress CMS";
$desc = "texTPress is a web application to publish the information through the website which is created by php using text files as data storage. texTPress is built without the need for setting the database. Once you finish putting the files to the server, this application can be executed directly.";
$kw = "textpress,cms,agc,auto blog";

$desc = substr(strip_tags($desc),0,180);
if (strlen($desc) < 60) {$desc = $desc." ".$setting[1];}
$kw = preg_replace('/[^A-Za-z0-9]/',' ',trim($kw));
	$ar_kw = explode(' ',$kw);
	$kw = "";
	foreach ($ar_kw as $item) {
		if (strlen($item) > 3) {$kw .= $item.","; }
	}
	$kw = substr($kw,0,-1);

$template = read_file('template_textpress.php');

include_once "lang.inc.php";

$template0 = in_string('','<!--start content-->',$template);
$template1 = in_string('<!--start content-->','<!--end content-->',$template);
$template2 = in_string('<!--end content-->','',$template);

echo $template0;
?>
isi web
<?php
echo $template2;
?>
