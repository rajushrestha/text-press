<?php

	include('color_harmony.class.php');
	$c = new colorHarmony;

	$c->isHEX($bgcolor);

	if($c->HEXError==1) {
		echo $c->HEXErrorMessage;
	} else {


		$mono = $c->Monochromatic($bgcolor);
		$analogic = $c->Analogous($bgcolor);
		$complement = $c->Complementary($bgcolor);
		$triad = $c->Triads($bgcolor);
		$rgba = $c->RGBA($bgcolor);
		
	}
?>