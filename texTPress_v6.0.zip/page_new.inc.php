<?php
include_once "functions.inc.php";

		$row_new = read_db('files/content_stats.txt',1,100);
		$row_new = array_sort($row_new,5,SORT_DESC);

$replace_new = '<ul class="list-unstyled">';
$count_new = 0;
foreach ($row_new as $column_new) {
	if (strlen($column_new[3]) > 11 && !stristr($replace_new,$column_new[1]) && !stristr($column_new[1],$path[1])) {
			$count_new++;
			$replace_new .= '
	  <li class="table table-condensed"><a href="'.$abs_url.$column_new[2].'/'.$column_new[1].'">'.$column_new[3].'</a></li>
	';
		if ($count_new >= 5) {break;}
	}
}
	if ($status_new != 'OK') {
		$status_new = $error_new;
	}
$replace_new .= '</ul>';
	$template = str_replace('{content_new}',$replace_new,$template);
?>