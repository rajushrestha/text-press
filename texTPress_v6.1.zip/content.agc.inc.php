<?php
/*
	AGC (c)2014 by Muhammad Fauzan Sholihin - tecnixindo@gmail.com - +6283840273173
*/
include_once "functions.inc.php";

$tags = urlencode(str_replace("-"," ",$path[0]));
$result = access_url('http://pipes.yahoo.com/pipes/pipe.run?_id=d1c6f35f62809e9552fdfa046a216a37&_render=rss&tags='.$tags);
if (stristr($result,'Warning: DOMDocument::load()')) {$result = "AGC is temporary unavailable to produce output result";}

$row_rss = explode("<item>",$result);
$i = 0;
foreach ($row_rss as $column_rss) {
	if ($i >= 1) {
		$permalink = in_string('<title>','</title>',$column_rss);
		$permalink = preg_replace('/[^0-9a-zA-Z]/',' ',$permalink);
		$permalink = preg_replace('/[^0-9a-zA-Z]/','-',trim($permalink));
		$column_related[1] = $permalink;
		$column_related[2] = date('Y-m-d H:i:s',strtotime(in_string('<pubDate>','</pubDate>',$column_rss)));
		$column_related[3] = in_string('<title>','</title>',$column_rss);
		$column_related[4] = in_string('<description>','</description>',$column_rss);
		$column_related[5] = "Post";
		$column_related[6] = "";
		$column_related[7] = "";
		$column_related[8] = "";
		$row_related[] = $column_related;
	}
	$i++;
}

?>