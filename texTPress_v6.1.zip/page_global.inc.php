<?php
include_once "functions.inc.php";

		$row_home = $row_global;
foreach ($row_home as $column_home) {
		$column_home[5] = date('D, d M Y - H:i',strtotime($column_home[5]));
		$home_list[$column_home[2]][] = $column_home;
}

//print_r($home_list); die();

	$files = file_list('files'); //print_r($files); die();
	foreach ($files as $nama_file) {
		if (stristr($nama_file,'.txt')) {
			$page_type = substr($nama_file,0,-4); //echo $page_type;
			$list = "";
	
			$pola0 = in_string('<!--start '.$page_type.'-->','<!--end '.$page_type.'-->',$template);
			for ($i=0;$i<count($home_list[$page_type]);$i++) {
				$pola1 = str_replace('[]','['.$i.']',$pola0);
				$list .= $pola1;
			}
			
				$template = str_replace($pola0,$list,$template);
			for ($i=0;$i<count($home_list[$page_type]);$i++) {
				if (strlen($home_list[$page_type][$i][3]) > 3 && !stristr($template,$home_list[$page_type][$i][1])) {
					$content_image = in_string('src="','"',$home_list[$page_type][$i][4]);
					if ($content_image == '') {$content_image = $abs_url."images/no_image.png";}
					$content = strip_tags(stripslashes($home_list[$page_type][$i][4]),"<br>");
					$template = str_replace('{'.$page_type.'_permalink['.$i.']}',$abs_url.$home_list[$page_type][$i][2].'/'.$home_list[$page_type][$i][1],$template);
					$template = str_replace('{'.$page_type.'_date['.$i.']}',$home_list[$page_type][$i][5],$template);
					$template = str_replace('{'.$page_type.'_title['.$i.']}',stripslashes($home_list[$page_type][$i][3]),$template);
					$template = str_replace('{'.$page_type.'_content['.$i.']}',$content,$template);
					$template = str_replace('{'.$page_type.'_img['.$i.']}',$content_image,$template);
					$template = str_replace('{'.$page_type.'_price['.$i.']}',$home_list[$page_type][$i][6],$template);
				}
			}
		}
	}

?>