<?php
// (c)2011 by Muhammad Fauzan Sholihin 		www.tetuku.com		Paypal donation: tecnixindo@gmail.com		Bank : BCA 0372344006 SwiftCode=CENA IDJA (Indonesia)
// Your donation will keep development process of this web apps. Thanks for your kindness
// You may use, modify, redistribute my apps for free as long as keep the origin copywrite
// Please give me backlink for my effort to develope this web based apps

include_once('functions.inc.php');

if ($_POST['send'] == 'site setting') {

//upload file
if ($_FILES['site_logo']['size'][$i] == '') { $data = $_POST['site_logo_old'][$i] ;}
if ($_FILES['site_logo']['size'][$i] != '') { 
$data = websafename($_POST['username']."-".$_FILES['site_logo']['name'][$i]); 
$tempdata = $_FILES['site_logo']['tmp_name'][$i]; 
if ($_POST['site_logo_old'][$i] != '') {
unlink ("files/".$_POST['site_logo_old'][$i]) ;
}
copy($tempdata, "files/".$data); 
}

$site_setting[1] = "SiteConfig" ;
$site_setting[2] = $_POST['meta_title'] ;
$site_setting[3] = $_POST['meta_desc'] ;
$site_setting[4] = $_POST['meta_kw'] ;
$site_setting[5] = $_POST['meta_author'] ;
$site_setting[6] = $_POST['bgcolor'] ;
$site_setting[7] = $_POST['logofont'] ;
$site_setting[8] = $data ;
$site_setting[9] = $_POST['overallfont'] ;

if ($_POST['key'] == '') {add_db('files/setting.txt',$site_setting) ;} else if ($_POST['key'] != '') {$site_setting[0] = $_POST['key'] ; edit_db('files/setting.txt',$site_setting) ;}

redirect($_SERVER['REQUEST_URI'], 0.1); die();
}

?>
<form action="<?php echo $formAction; ?>" method="POST" enctype="multipart/form-data" name="form1" id="form1">
      <table width="666" border="0" cellspacing="0" cellpadding="2" class="table table-condensed">
        <tr>
          <td width="130" align="right" valign="top">        Site name*:</td>
          <td align="left" valign="top"><input name="site_name" type="text" id="site_name" value="<? echo $setting[SiteConfig][2] ;?>" size="40">
              </td>
        </tr>
        <tr>
          <td align="right" valign="top">          Site tag:</td>
          <td align="left" valign="top"><input name="site_tag" type="text" id="site_tag" value="<? echo $setting[SiteConfig][3] ;?>" size="40">
              </td>
        </tr>
        <tr valign="baseline">
          <td nowrap align="right">Base color: </td>
          <td>
<link href="<?=$abs_url?>css/bootstrap-colorpicker.css" rel="stylesheet">
            <input name="bgcolor" type="text" id="Color1" size="8" maxlength="7" value="#FF0000" class="form-control warna warna-1 warna-auto" />
          </td>
        </tr>
        <tr>
          <td align="right" valign="top">    Site logo:</td>
          <td align="left" valign="top"><input name="site_logo_old" type="hidden" id="site_logo_old" value="<? echo $setting[SiteConfig][4] ;?>" size="40">
            <input name="site_logo" type="file" id="site_logo" size="33"></td>
        </tr>
        <tr>
          <td align="right" valign="top">Logo font : </td>
          <td align="left" valign="top"><input name="logofont" type="text" id="logofont" value="<? if($setting[SiteConfig][5] != '') {echo $setting[SiteConfig][5];} else if ($setting[SiteConfig][5] == '') {echo "Peralta";}?>" size="33"> 
            <small>(<a href="http://www.google.com/webfonts" target="_blank">? font list</a>)</small></td>
        </tr>
        <tr>
          <td align="right" valign="top">Overall  font : </td>
          <td align="left" valign="top"><input name="overallfont" type="text" id="overallfont" value="<? if($setting[SiteConfig][7] != '') {echo $setting[SiteConfig][7];} else if ($setting[SiteConfig][7] == '') {echo "Open Sans";}?>" size="33"> 
            <small>(<a href="http://www.google.com/webfonts" target="_blank">? font list</a>)</small></td>
        </tr>
        <tr>
          <td align="right" valign="top"><input name="key" type="hidden" id="key" value="<? echo $setting[SiteConfig][0] ;?>"></td>
          <td align="left" valign="top">
        <input name="Submit" type="submit" id="Submit" value="<?=$btn_save?>">
        <input name="send" type="hidden" id="send" value="site setting">
		  &nbsp;</td>
        </tr>
      </table>
    </form>
    <script src="<?=$abs_url?>js/bootstrap-colorpicker.js"></script>
    <script src="<?=$abs_url?>js/colorpicker.js"></script>
<?php
include_once "process_last.inc.php";
?>