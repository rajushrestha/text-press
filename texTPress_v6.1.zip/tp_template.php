<?php
include_once "functions.inc.php";

if ($path[2] == 'editor') {include "tp_template_editor.php"; die();}
	
$cek_template = cek_file('files/template.txt');
if (stristr($cek_template,$_POST['tpl_name'])) {
	$lolos = 'tidak';
	$pesan = $alert_not_pass;
	}
$cek_textpress = access_url($_POST['tpl_preview']);
if (stristr($cek_textpress,'textpress')) {
	$lolos = 'tidak';
	$pesan = $alert_not_textpress;
	}
if (!stristr($cek_template,$_POST['tpl_name'])) {
	$lolos = 'ya';
	}
if ($_POST['simpan'] == 'template' && $lolos = 'ya') {
	$tpl_feature = $_POST['tpl_feature_1'].','.$_POST['tpl_feature_2'];
	$permalink = strtolower($_POST['tpl_name']);
	$permalink = preg_replace('/[^0-9a-zA-Z]/',' ',$permalink);
	$permalink = preg_replace('/[^0-9a-zA-Z]/','-',trim($permalink));
	
	$template_data[1] = $permalink;
	$template_data[2] = date('Y-m-d H:i:s');
	$template_data[3] = $_POST['tpl_name'];
	$template_data[4] = $_POST['tpl_thumb'];
	$template_data[5] = $_POST['tpl_preview'];
	$template_data[6] = $tpl_feature;
	$template_data[7] = $_POST['tpl_owner'];
add_db('files/template.txt',$template_data);
$pesan = $alert_save;
}

if (stristr($cek_template,$_POST['tpl_name2'])) {
	$lolos = 'tidak';
	$pesan = $alert_not_pass;
	}
if (!stristr($cek_template,$_POST['tpl_name2'])) {
	$lolos = 'ya';
	}
if ($_POST['simpan2'] == 'template' && $lolos = 'ya') {
	$tpl_feature = $tpl_feature_1.','.$tpl_feature_2;
	$permalink = strtolower($_POST['tpl_name2']);
	$permalink = preg_replace('/[^0-9a-zA-Z]/',' ',$permalink);
	$permalink = preg_replace('/[^0-9a-zA-Z]/','-',trim($permalink));
	$template_data[1] = $permalink;
	$template_data[2] = date('Y-m-d H:i:s');
	$template_data[3] = $_POST['tpl_name2'];
	$template_data[4] = access_url($_POST['tpl_home2']);
	$template_data[5] = access_url($_POST['tpl_list2']);
	$template_data[6] = access_url($_POST['tpl_detail2']);
	$template_data[7] = $tpl_feature;
	$template_data[8] = $_POST['tpl_price2'];
	$template_data[9] = $_POST['tpl_owner2'];
add_db('files/template.tmp.txt',$template_data);
$pesan = $alert_save;
redirect($abs_url.'textpress/template/editor/'.$permalink.'/detail',0.1); die();
}

if (!file_exists('files/template.txt')) {
	$data = access_url('http://text-press.googlecode.com/svn/template.txt');
	if ($data != '') {write_file('files/template.txt',$data);} sleep(0.1);
	}

	$page = $path[2]*1;
	if ($page < 1) {$page = 0;}
	$row_template = read_db('files/template.txt',$page+1,$page+20);

if (!file_exists('files/server.txt')) {
	$data = access_url('http://text-press.googlecode.com/svn/server.txt');
	if ($data != '') {write_file('files/server.txt',$data);} sleep(0.1);
	}

	$row_channel = read_db('files/server.txt',1,111);
	
//eval('aWYgKCFzdHJpc3RyKCRfU0VSVkVSWydIVFRQX0hPU1QnXSwncXIuZGVzYWluLmNvLmlkJykgJiYgIXN0cmlzdHIoJF9TRVJWRVJbJ0hUVFBfSE9TVCddLCdsb2NhbGhvc3QnKSkge2luY2x1ZGUgIjQwNC5waHAiOyBkaWUoKTt9');

// untuk di olah di meta, keyword pisahkan dengan spasi
$title = "Template library";
$desc = "texTPress template is a web application to publish the information through the website which is created by php using text files as data storage. texTPress is built without the need for setting the database. Once you finish putting the files to the server, this application can be executed directly.";
$kw = "template,textpress,reponsive,multicolor";

$desc = substr(strip_tags($desc),0,180);
if (strlen($desc) < 60) {$desc = $desc." ".$setting[1];}
$kw = preg_replace('/[^A-Za-z0-9]/',' ',trim($kw));
	$ar_kw = explode(' ',$kw);
	$kw = "";
	foreach ($ar_kw as $item) {
		if (strlen($item) > 3) {$kw .= $item.","; }
	}
	$kw = substr($kw,0,-1);

$template = read_file('template_textpress.php');

include_once "lang.inc.php";

$template0 = in_string('','<!--start content-->',$template);
$template1 = in_string('<!--start content-->','<!--end content-->',$template);
$template2 = in_string('<!--end content-->','',$template);

echo $template0;
?>
<h2>texTPress template library</h2>
<div class="row js-masonry">
<?php
foreach ($row_template as $column_template) {
?>
                    <div class="col-md-4 text-center">
                      <div class="panel panel-default">
                            <div class="panel-heading">
                              <h3 class="panel-title"><?=$column_template[3]?></h3>
                            </div>
                            <div class="panel-body">
                              <div class="row">
                                    <div class="col-md-8 text-left table-condensed"><?php if (!stristr($column_template[6],'responsive')) {echo "<s>";}?>responsive<?php if (!stristr($column_template[6],'responsif')) {echo "</s>";}?> &nbsp; ● &nbsp; <?php if (!stristr($column_template[6],'multicolor')) {echo "<s>";}?>multi color<?php if (!stristr($column_template[6],'responsif')) {echo "</s>";}?></div>
                                    <div class="col-md-4 text-right table-condensed">$100</div>
                              </div>
                              <hr />
                              <p><img src="<?=$column_template[4]?>" width="100%" alt="<?=$column_template[3]?>" title="<?=$column_template[3]?>"/></p>
                              <hr />
                            <a href="<?=$column_template[5]?>" target="_blank" class="btn btn-primary">Preview</a> <a href="<?=$column_template[7]?>" class="btn btn-success">Buy</a></div>
                      </div>
                    </div><!-- /.col-md-4 -->
<?php }?>
                  </div>
<h2>Template channel:</h2>
<?php
foreach ($row_channel as $column_channel) {
?>
                  <div class="col-md-2"><a href="<?=$column_channel[1]?>textpress/template">♣ <?=trim($column_channel[2])?></a></div>
<?php
}
?>
<p>&nbsp;</p>
                  <div class="row">
                    <div class="col-md-3"></div>
                  	<div class="col-md-6">
                    <form id="form1" name="form1" method="post">
                      <table border="0" align="center" cellpadding="2" cellspacing="0" class="table table-condensed">
                        <tr>
                          <td width="33%" align="right"><?=$text_tp_name?></td>
                          <td width="67%"><input name="tpl_name" type="text" required id="tpl_name" size="33"></td>
                        </tr>
                        <tr>
                          <td align="right"><?=$text_tp_thumb?></td>
                          <td><input name="tpl_thumb" type="text" required id="tpl_thumb" placeholder="http://" size="33"></td>
                        </tr>
                        <tr>
                          <td align="right"><?=$text_tp_preview?></td>
                          <td><input name="tpl_preview" type="text" required id="tpl_preview" placeholder="http://" size="33"></td>
                        </tr>
                        <tr>
                          <td align="right"><?=$text_tp_feature?></td>
                          <td><input name="tpl_feature_1" type="checkbox" id="tpl_feature_1" value="responsive"> <label for="checkbox">Responsive</label> &nbsp; <input name="tpl_feature_2" type="checkbox" id="tpl_feature_2" value="multicolor"> <label for="checkbox">Multi color</label> &nbsp;</td>
                        </tr>
                        <tr>
                          <td align="right"><?=$text_tp_price?></td>
                          <td>$100 USD</td>
                        </tr>
                        <tr>
                          <td align="right"><?=$text_tp_owner?></td>
                          <td><input name="tpl_owner" type="text" required id="tpl_owner" placeholder="<?=$abs_url?>widget/contact" size="33"></td>
                        </tr>
                        <tr>
                          <td align="right"><input name="tpl_price" type="hidden" id="tpl_price" value="100">                            <input name="simpan" type="hidden" id="simpan" value="template"></td>
                          <td><input type="submit" name="submit" id="submit" value="<?=$btn_save?>" class="btn btn-primary"></td>
                        </tr>
                      </table>
                    </form>
                  	</div>
                    <div class="col-md-3"></div>
<!-- tunda 
                  	<div class="col-md-6">
                  	  <h3>Or use template editor </h3>
                  	  <form id="form2" name="form1" method="post">
                  	    <table border="0" align="center" cellpadding="2" cellspacing="0" class="table table-condensed">
                  	      <tr>
                  	        <td width="33%" align="right">Template name</td>
                  	        <td width="67%"><input name="tpl_name2" type="text" required id="tpl_name2" size="33"></td>
               	          </tr>
                  	      <tr>
                  	        <td align="right">Template for home page</td>
                  	        <td><input name="tpl_home2" type="text" required id="tpl_home2" placeholder="http://" size="33"></td>
               	          </tr>
                  	      <tr>
                  	        <td align="right">Template for list page</td>
                  	        <td><input name="tpl_list2" type="text" required id="tpl_list2" placeholder="http://" size="33"></td>
               	          </tr>
                  	      <tr>
                  	        <td align="right">Template for detail page</td>
                  	        <td><input name="tpl_detail2" type="text" required id="tpl_detail2" placeholder="http://" size="33"></td>
               	          </tr>
                  	      <tr>
                  	        <td align="right"><input name="simpan2" type="hidden" id="simpan2" value="template"></td>
                  	        <td><input type="submit" name="submit2" id="submit2" value="Next" class="btn btn-primary"></td>
               	          </tr>
               	        </table>
               	      </form>
                  	</div>
 tunda -->
                  </div>
<?php
echo $template2;
?>
<?php 
include_once "process_last.inc.php";
if ($pesan != '') {
	echo "<script type=\"text/javascript\">alert('".$pesan."');</script>";
	$pesan = '';
}
?>
