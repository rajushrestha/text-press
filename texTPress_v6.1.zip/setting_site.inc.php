<?php
// (c)2011 by Muhammad Fauzan Sholihin 		www.tetuku.com		Paypal donation: tecnixindo@gmail.com		Bank : BCA 0372344006 SwiftCode=CENA IDJA (Indonesia)
// Your donation will keep development process of this web apps. Thanks for your kindness
// You may use, modify, redistribute my apps for free as long as keep the origin copywrite
// Please give me backlink for my effort to develope this web based apps

include_once('functions.inc.php');

?>
<a href="<?=$abs_url?><? if ($_SESSION['level'] == 'Admin') {echo "setting_site.php?edit=OK";} else {?>./<? }?>" title="<? if ($_SESSION['level'] == 'Admin') {echo "Click to change";} ?>">
<span style="font-size:24pt; font-family:'<? echo $setting[SiteConfig][5] ;?>'; color:<? echo $_SESSION['mono'][4];?>">
<?php if (strlen($setting[SiteConfig][6]) >= 6) {echo "<img src=\"files/".$setting[SiteConfig][6]."\" border=\"0\" height=\"100\">"; }?>
<?php if ($setting[SiteConfig][1] != '') {echo $setting[SiteConfig][2]; } else if ($setting[SiteConfig][1] == '') {echo "Your Company Name";} ?>
<?php if ($setting[SiteConfig][3] != '') {echo "</span><br /><small> &nbsp; ".$setting[SiteConfig][3]."</small>"; } ?></a>