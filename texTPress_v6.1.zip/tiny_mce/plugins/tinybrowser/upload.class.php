<?php
	/**
	 * License GPL v2+
	 * Author: Chunjie Lu<luchunjie.lu@gmail.com>
	 * Description: A friendly, easy-to-use file upload plugin for tinyMCE. If you would like, feel free to share ideas with me for the plugin
	 * Revision: v0.1
	 * Publication date: 2012-04-23 11:19
	 */
	 
    /**
     * 实现一个上传的处理类
     * 
     * 支持两种情况,编码文件名或者非编码文件名
     * 自动化处理上传
     * 支持不同的操作系统
     */ 

    class upload{
        /**
        * varibles for storage only
        */
        private $arrFile = array();
        
        /**
        * varibles for error info
        */
        public  $error   = array();
        /**
        * 成功上传数量
        */
        private $uploaded=0;
        /**
        * 将相关的文件名保存在数据库中
        */
        public $uploadSetting = '';
        /**
        * variables for configuration only
        */
        private $suffixAllowed=array('.jpg','.gif','.png','.bmp','.txt','.pdf', '.rar', '.doc', '.zip', '.gz', '.tar');//上传文件扩展名
        private $suffixRejected=array('.php');//拒绝的扩展名
        private $max_length_filename  = 50;//最大文件名长度
        private $max_upload_size      = 20000000;//最大上传文件尺寸，不能超出 php.ini 中的 upload_max_filesize 、post_max_size 值
        private $max_single_file_size = 1000000;//单个文件上传尺寸，不能超出 php.ini 中的 upload_max_filesize 、post_max_size 值
        private $allow_replace_always = false;//是否允许覆盖
        /**
        * 示例
        * 
        * <p>
        * parameter $folder must suffix '/'
        * <code>
        * $upload=new upload('str_replace('\\','/',dirname(__FILE__) . '/upload/'),'http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['SCRIPT_NAME']).'/download.php?filename=',true);
        * //or
        * $upload=new upload('c:/htdocs/inc/upload/','http://example.com/inc/download.php?filename=');
        * </code>
        * </p>
        * 
        * @param $folder string 保存路径
        * @param $folderurl string 保存路径的相应url,如果是编码文件名的话是download.php的路径
        * @param $encoding boolean 是否对文件名进行编码,以允许所有文件名
        * @param $lang array|bool language array, keys will be prefixed by lang_, with no collision allowed
        * @return null
        */
        public function __construct($folder, $folderurl, $encoding=true, $lang=null){
        	if($lang) extract($lang, EXTR_PREFIX_ALL, 'lang');
        	
            $accumulation = 0;//计算值
            $old          = umask(0);//旧掩码值
            
            if($_SERVER['REQUEST_METHOD']=='POST'){
                foreach($_FILES as $k=>$arr){
                    if($arr['error']===0){
                        $suffix=strtolower(strrchr($arr['name'], '.'));
                        if($accumulation+$arr['size']>$this->max_upload_size){
                            $this->error[$k] = $lang_upload_file . $arr['name'] . $lang_system_limit_of_all . round($this->max_upload_size/1048576,1).'M';
                            continue;
                        }
                        
                        if($arr['size']>$this->max_single_file_size){
                            $this->error[$k] = $lang_upload_file . $arr['name'] . $lang_system_limit_of_one . round($this->max_single_file_size/1048576,1).'M';
                            continue;
                        }
                        
                        if(!in_array($suffix,$this->suffixAllowed) && !$encoding){
                            $this->error[$k] = $lang_upload_file . $arr['name'] . $lang_unsupport_filetype;
                            continue;
                        }
                        
                        if(in_array($suffix,$this->suffixRejected)){
                            $this->error[$k] = $lang_upload_file . $arr['name'] . $lang_forbidden_filetype;
                            continue;
                        }
                        
                        if(mb_strlen($arr['name'],'utf-8')>$this->max_length_filename){
                            $this->error[$k] = $lang_upload_file.$arr['name'] . $lang_too_long_file_name;
                            continue;
                        }
                        
                        $arr['name'] = strtr($arr['name'], '&<>"\'/:','__________');//生成文件名
                        $fileSrcName = $arr['name'];
                        if(PHP_SHLIB_SUFFIX == 'dll' && !$encoding){
                            $arr['name'] = mb_convert_encoding($arr['name'], 'gbk', 'utf-8');
                        }
                        
                        $encoded_name = $encoding ? bin2hex(mb_convert_encoding($arr['name'], 'gbk', 'utf-8')) : $arr['name'];//转换过的文件名
                        
                        if(!$this->isAcceptable($folder.$encoded_name)){
                        	$prefix = ($_SERVER['REQUEST_TIME'] - 1334651520) . '_';//生成前缀
                        	$encoded_name = $prefix . $encoded_name;
						}
						else{
							$prefix = '';
						}
                        
                        $this->arrFile[$k]['storage_name'] = $folder.$encoded_name;//文件系统中的文件名
                        $this->arrFile[$k]['url'] = $folderurl.rawurlencode($encoded_name);//URL中的名称
                        
                        if(!$this->isAcceptable($this->arrFile[$k]['storage_name'])){
                            $this->error[$k] = $lang_upload_file . $fileSrcName . $lang_exist_file;
                            continue;
                        }
                        
                        if(move_uploaded_file($arr['tmp_name'], $this->arrFile[$k]['storage_name'])){
                            chmod($this->arrFile[$k]['storage_name'] , 0644);//更改文件模式
                            if($this->uploaded>0) $this->uploadSetting .= '/';
                            $this->uploadSetting .= $prefix.$fileSrcName;//数据库存储的名称=>可以得到文件系统文件名
                            $this->error[$k]      = $lang_upload_file . $fileSrcName . $lang_upload_success;
                            $this->arrFile[$k]['success'] = true;
                            $this->uploaded++;
                        }
                        else
                            $this->error[$k] = $lang_upload_file . $fileSrcName . $lang_storage_error;
                    }
                    else{
                    	switch($arr['error']){
                    	case UPLOAD_ERR_INI_SIZE:
                    	case UPLOAD_ERR_FORM_SIZE:
                    		$this->error[$k] = $lang_upload_file.$arr['name'] . $lang_system_limit_of_one . round($this->max_single_file_size/1048576,1).'M';
                    		break;
                    	case UPLOAD_ERR_PARTIAL:
                    	case UPLOAD_ERR_NO_FILE:
                    		$this->error[$k] = $lang_upload_file.$arr['name'] . $lang_upload_partial;
                    		break;
                    	case UPLOAD_ERR_NO_TMP_DIR:
                    	case UPLOAD_ERR_CANT_WRITE:
                    		$this->error[$k] = $lang_upload_file.$arr['name'] . $lang_internal_error;
                    		break;
						}
					}
                }
            }
            umask($old);
        }
        
        /**
        * 如果上传不成功,可以返回上传信息
        * @translation error info in case of unsuccessful upload
        * 
        * @param $array boolean 是否返回数组信息
        * @return string|array 相关错误信息
        */
        public function showUploadError($array=false, $sep = '<br />'){
            return $array? $this->error : implode($sep, $this->error);
        }
        
        /**
        * 返回上传的文件url
        * @translation the url of the file uploaded
        * 
        * @return string
        */
        public function getUrls(){
            $urls=array();
            foreach($this->arrFile as $v){
                if($v['success']) $urls[]=$v['url'];
            }
            return $urls;
        }
        
        /**
        * 表明执行上传是否成功
        * @translation whether upload is successful
        * @return bool
        */
        public function isSuccess(){
            return $this->uploaded==count($_FILES);
        }
        
        /**
        * 返回文件名是否已经存在
        * @translation indicate whether filename already exists
        * @return bool
        */
        public function isAcceptable($filename) {
            if ($this->allow_replace_always){
                return true;
            }
            else{
                clearstatcache();
                return !file_exists($filename);
            }
        }
    }