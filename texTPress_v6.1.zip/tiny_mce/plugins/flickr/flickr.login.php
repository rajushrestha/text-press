<?php
require_once("flickr.class.php");//chage to your directory
session_start();//we will use session , so be sure you have this rights
$fk=new curlflickr;
$fk->api_key="cff94697d8359b02a58d12e7044d5c4d";//set your api
$fk->secret="340aa31e37740a65";//set your secret code
$fk->$auth_token="72157632866825659-539ab5d42b0724f6";//session after login
$fk->auth("write",TRUE);//you can just use $fk->auth(); is fine
$fk->sessionname="flickr_session_upload";//define your session if you like,this will help to change to another flickr account
?>