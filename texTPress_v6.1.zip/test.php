<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<title>Calypso - MultiPurpose Responsive Template - Bootstrap 3</title>
<!-- Style -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<!-- Responsive -->
<link href="css/responsive.css" rel="stylesheet">
<!-- Choose Layout -->
<link href="css/layout-semiboxed.css" rel="stylesheet">
<!-- Choose Skin -->
<link href="css/skin-red.css" rel="stylesheet">
<!-- Demo -->
<link rel="stylesheet" id="main-color" href="css/skin-red.css" media="screen"/>
<!-- Favicon -->
<link rel="shortcut icon" href="img/favicon.ico">
<!-- IE -->
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>	   
<![endif]-->
<!--[if lte IE 8]>
<link href="css/ie8.css" rel="stylesheet">
<![endif]-->
</head>
<body class="off">
<!-- /.wrapbox start-->
<div class="wrapbox">
	<!-- TOP AREA
================================================== -->
	<section class="toparea">
	<div class="container">
		<div class="row">
			<div class="col-md-6 top-text pull-left animated fadeInLeft">
				<i class="icon-phone"></i> Phone: (316) 444 8529 <span class="separator"></span><i class="icon-envelope"></i> Email: <a href="#">wowthemesnet@gmail.com</a>
			</div>
			<div class="col-md-6 text-right animated fadeInRight">
				<div class="social-icons">
					<a class="icon icon-facebook" href="#"></a>
					<a class="icon icon-twitter" href="#"></a>
					<a class="icon icon-linkedin" href="#"></a>
					<a class="icon icon-skype" href="#"></a>
					<a class="icon icon-google-plus" href="#"></a>
				</div>
			</div>
		</div>
	</div>
	</section>
	<!-- /.toparea end-->
	<!-- NAV
================================================== -->
	<nav class="navbar navbar-fixed-top wowmenu" role="navigation">
	<div class="container">
		<div class="navbar-header">
			<a class="navbar-brand logo-nav" href="index.html"><img src="img/logo.png" alt="logo"></a>
		</div>
		<ul id="nav" class="nav navbar-nav pull-right">
			<li><a href="index.html">Home</a></li>
			<li class="dropdown active">
			<a href="#" class="dropdown-toggle" data-toggle="dropdown">Pages <i class="icon-angle-down"></i></a>
			<ul class="dropdown-menu">
				<li><a href="home2.html">Home Alt</a></li>
				<li><a href="about.html">About Us</a></li>
				<li><a href="services.html">Services</a></li>
				<li><a href="timeline.html">Timeline</a></li>
				<li><a href="landingpage.html">Landing Page</a></li>
				<li><a href="testimonials.html">Testimonials</a></li>
				<li><a href="faq.html">F.A.Q.</a></li>
				<li><a href="404.html">404 Not Found</a></li>
			</ul>
			</li>
			<li class="dropdown">
			<a href="#" class="dropdown-toggle" data-toggle="dropdown">Portfolio <i class="icon-angle-down"></i></a>
			<ul class="dropdown-menu">
				<li><a href="portfolio3.html">Three Columns</a></li>
				<li><a href="portfolio2.html">Two Columns</a></li>
				<li><a href="portfolio4.html">Four Columns</a></li>
				<li><a href="projectdetail.html">Single Project</a></li>
			</ul>
			</li>
			<li class="dropdown">
			<a href="#" class="dropdown-toggle" data-toggle="dropdown">Blog <i class="icon-angle-down"></i></a>
			<ul class="dropdown-menu">
				<li><a href="blogindex.html">Home Blog</a></li>
				<li><a href="blogsinglepost.html">Single Post</a></li>
			</ul>
			</li>
			<li class="dropdown">
			<a href="#" class="dropdown-toggle" data-toggle="dropdown">Features <i class="icon-angle-down"></i></a>
			<ul class="dropdown-menu">
				<li><a href="elements.html">Elements</a></li>
				<li><a href="columns.html">Columns</a></li>
				<li><a href="icons.html">Icons</a></li>
				<li><a href="#">Masonry Grids +</a>
				<ul class="dropdown-menu sub-menu">
					<li><a href="masonry2.html">Masonry Two</a></li>
					<li><a href="masonry3.html">Masonry Three</a></li>
					<li><a href="masonry4.html">Masonry Four</a></li>
				</ul>
				</li>
			</ul>
			</li>
			<li><a href="contact.html">Contact</a></li>
		</ul>
	</div>
	</nav>
	<!-- /nav end-->
	<!-- HEADER IMAGE AREA
================================================== -->
	<section class="pageheader-default" style="background:url(img/demo/slide3.jpg);">
	<div class="bgarea-semitransparent">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<h1 class="landingpage animated fadeInLeftBig notransition topspace20">Landing Page for product</h1>
					<h3 class="landingpage animated fadeInDownBig notransition">Unique design, multiple layouts, skin colors<br/> multipurpose & Bootstrap 3.0 + compatible</h3>
					<div class="landingpage-button animated fadeInUpBig">
						<a href="#">
						<i class="icon-mobile-phone icon-4x"></i><span>Available on WowThemes.net <br>
						<strong>Online Store</strong></span></a>
					</div>
				</div>
				<div class="col-md-6">
					<img src="img/demo/desktop3.png" class="img-responsive animated fadeInRightBig" alt="">
				</div>
			</div>
		</div>
	</div>
	</section>
	<div class="wrapsemibox">
		<div class="semiboxshadow text-center">
			<img src="img/shp.png" class="img-responsive" alt="">
		</div>
		<!-- FORM+INTRO NOTE
================================================== -->
		<section class="container services">
		<div class="row">
			<div class="col-md-4 animated fadeInLeft notransition">
				<div class="box effect2">
					<h4>GOT A PRE-SALE QUESTION?</h4>
					<p>
						 There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration.
					</p>
					<div class="done">
						<div class="alert alert-success">
							<button type="button" class="close" data-dismiss="alert">�</button>
							Your message has been sent. Thank you!
						</div>
					</div>
					<form method="post" action="contact.php" id="contactform">
						<div class="form">
							<input class="col-md-12" type="text" name="name" placeholder="Name">
							<input class="col-md-12" type="text" name="email" placeholder="E-mail">
							<textarea class="col-md-12" name="comment" rows="3" placeholder="Message"></textarea>
							<input type="submit" id="submit" class="btn btn-default" value="Send">
						</div>
					</form>
				</div>
			</div>
			<div class="col-md-8 animated fadeInRight notransition">
				<div class="row text-center">
					<div class="col-md-6">
						<i class="icon-microphone"></i>
						<h4>READY TO USE</h4>
						<p>
							 There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form. Praesent tempus eleifend risus ut congue eset nec lacus.
						</p>
					</div>
					<!-- col-md-6 -->
					<div class="col-md-6">
						<i class="icon-magic"></i>
						<h4>CSS3 ANIMATIONS</h4>
						<p>
							 There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form. Praesent tempus eleifend risus ut congue eset nec sit amet, tempor sem.
						</p>
					</div>
					<!-- col-md-6 -->
				</div>
				<div class="row text-center">
					<br>
					<br>
					<div class="col-md-6">
						<i class="icon-desktop"></i>
						<h4>TOP SUPPORT</h4>
						<p>
							 There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form. Praesent tempus eleifend risus ut congue eset nec sit amet, tempor sem.
						</p>
					</div>
					<!-- col-md-6 -->
					<div class="col-md-6">
						<i class="icon-leaf"></i>
						<h4>BEST CLIENTS</h4>
						<p>
							 There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form. Praesent tempus eleifend risus ut congue eset nec nec sit amet, tempor sem.
						</p>
					</div>
					<!-- col-md-6 -->
				</div>
			</div>
		</div>
		</section>
		<!-- TESTIMONIALS
================================================== -->
		<section class="topspace10">
		<div class="container animated fadeInRightNow notransition">
			<div class="row">
				<h1 class="text-center smalltitle">
				<span>Testimonials</span>
				</h1>
				<div id="cbp-qtrotator" class="cbp-qtrotator">
					<div class="cbp-qtcontent">
						<img src="../../../wowthemes.net/demo/biscaya/img/demo/avatar.jpg" alt="">
						<blockquote>
							<p class="bigquote">
								<i class="icon-quote-left colortext quoteicon"></i> Lorem ipsum dolor sit adipiscing elit. Praesent tempus eleifend risus ut congue eset nec lacus. Lorem ipsum dolor sit adipiscing elit. Praesent tempus eleifend risus ut congue eset nec lacus. Praesent dignissim sem sapien, a vulputate enim auctor vitae. Duis non lorem porta, adipiscing eros sit amet, tempor sem.
							</p>
							<footer>Pino Caruso</footer>
						</blockquote>
					</div>
					<div class="cbp-qtcontent">
						<img src="../../../wowthemes.net/demo/biscaya/img/demo/avatar.jpg" alt="">
						<blockquote>
							<p class="bigquote">
								<i class="icon-quote-left colortext quoteicon"></i> Lorem ipsum dolor sit adipiscing elit. Praesent tempus eleifend risus ut congue eset nec lacus. Lorem ipsum dolor sit adipiscing elit. Praesent tempus eleifend risus ut congue eset nec lacus. Praesent dignissim sem sapien, a vulputate enim auctor vitae. Duis non lorem porta, adipiscing eros sit amet, tempor sem.
							</p>
							<footer>Pino Caruso / Director of <a href="#">example.com</a></footer>
						</blockquote>
					</div>
				</div>
			</div>
		</div>
		</section>
		<!-- FEATURES
================================================== -->
		<section class="grayarea home-features">
		<div class="container">
			<div class="row">
				<div class="col-md-10 col-md-offset-1">
					<h1 class="small text-center animated fadeInLeftNow notransition">PRODUCT FEATURES</h1>
					<div class="br-hr type_short">
						<span class="br-hr-h animated fadeInRightNow">
						<i class="icon-pencil"></i>
						</span>
					</div>
					<div class="row animated fadeInDownNow notransition">
						<div class="col-md-4">
							<h4><i class="icon icon-microphone">
							</i> Winning Theme</h4>
							<div class="bottomspace30">
								 Trigger ideas: quickly experiment with site colors &amp; patterns, try out web typography and much more.
							</div>
						</div>
						<div class="col-md-4">
							<h4><i class="icon icon-heart">
							</i> Love at First sight</h4>
							<div class="bottomspace30">
								 Trigger ideas: quickly experiment with site colors &amp; patterns, try out web typography and much more.
							</div>
						</div>
						<div class="col-md-4">
							<h4><i class="icon icon-user">
							</i> Modern Template</h4>
							 Trigger ideas: quickly experiment with site colors &amp; patterns, try out web typography and much more. <br>
						</div>
					</div>
					<div class="row animated fadeInUpNow notransition">
						<div class="col-md-4">
							<h4><i class="icon icon-user">
							</i> Ready to Use</h4>
							 Trigger ideas: quickly experiment with site colors &amp; patterns, try out web typography and much more. <br>
						</div>
						<div class="col-md-4">
							<h4><i class="icon icon-cogs">
							</i> Great for clients</h4>
							 Trigger ideas: quickly experiment with site colors &amp; patterns, try out web typography and much more. <br>
						</div>
						<div class="col-md-4">
							<h4><i class="icon icon-leaf">
							</i> MultiPurpose Use</h4>
							<div class="bottomspace30">
								 Trigger ideas: quickly experiment with site colors &amp; patterns, try out web typography and much more.
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		</section>
		<!-- BEGIN CALL TO ACTION PANEL
================================================== -->
		<section class="container animated fadeInDownNow notransition topspace40">
		<div class="row">
			<div class="col-md-12">
				<div class="text-center">
					<p class="bigtext">
						 Praesent <span class="fontpacifico colortext">WowThemes</span> sapien, a vulputate enim auctor vitae
					</p>
					<p>
						 Duis non lorem porta, adipiscing eros sit amet, tempor sem. Donec nunc arcu, semper a tempus et, consequat
					</p>
				</div>
				<div class="text-center topspace20">
					<a href="#" class="buttonblack"><i class="icon-shopping-cart"></i>&nbsp; get theme</a>
					<a href="#" class="buttoncolor"><i class="icon-link"></i>&nbsp; learn more</a>
				</div>
			</div>
		</div>
		</section>
		<!-- /. end call to action-->
	</div>
	<!-- /.wrapsemibox end-->
	<!-- BEGIN FOOTER
================================================== -->
	<section>
	<div class="footer">
		<div class="container animated fadeInUpNow notransition">
			<div class="row">
				<div class="col-md-4">
					<h1 class="footerbrand">Calypso</h1>
					<p>
						 Introducing a premium HTML5 & CSS3 template for multipurpose use.
					</p>
					<p>
						 Three awesome layouts, beautiful modern design, lots of features and skins.
					</p>
					<p>
						 Made with &nbsp;<i class="icon-heart"></i>&nbsp; by WowThemes.net.
					</p>
				</div>
				<div class="col-md-4">
					<h1 class="title"><span class="colortext">F</span>ind <span class="font100">Us</span></h1>
					<div class="footermap">
						<p>
							<strong>Address: </strong> No.42 - 54816 Inc Calypso
						</p>
						<p>
							<strong>Phone: </strong> + 1 (280) 482 9537
						</p>
						<p>
							<strong>Fax: </strong> + 1 (372) 742 9532
						</p>
						<p>
							<strong>Email: </strong> wowthemesnet@gmail.com
						</p>
						<ul class="social-icons list-soc">
							<li><a href="#"><i class="icon-facebook"></i></a></li>
							<li><a href="#"><i class="icon-twitter"></i></a></li>
							<li><a href="#"><i class="icon-linkedin"></i></a></li>
							<li><a href="#"><i class="icon-google-plus"></i></a></li>
							<li><a href="#"><i class="icon-skype"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-4">
					<h1 class="title"><span class="colortext">C</span>lients' <span class="font100">Voice</span></h1>
					<div id="quotes">
						<div class="textItem">
							<div class="avatar">
								<img src="../../../wowthemes.net/demo/biscaya/img/demo/avatar.jpg" alt="avatar">
							</div>
							 "Before turning to those moral and mental aspects of the matter which present the greatest difficulties, let the inquirer begin by mastering more elementary problems.<span style="font-family:arial;">"</span><br/><b> Jesse T, Los Angeles </b>
						</div>
						<div class="textItem">
							<div class="avatar">
								<img src="../../../wowthemes.net/demo/biscaya/img/demo/avatar.jpg" alt="avatar">
							</div>
							 "How often have I said to you that when you have eliminated the impossible, whatever remains, however improbable, must be the truth?<span style="font-family:arial;">"</span><br/><b>Ralph G. Flowers </b>
						</div>
					</div>
					<div class="clearfix">
					</div>
				</div>
			</div>
		</div>
	</div>
	<p id="back-top">
		<a href="#top"><span></span></a>
	</p>
	<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<p class="pull-left">
						 &copy; Copyright 2014 WowThemes.net
					</p>
				</div>
				<div class="col-md-8">
					<ul class="footermenu pull-right">
						<li><a href="#">Home</a></li>
						<li><a href="#">Work</a></li>
						<li><a href="#">Pages</a></li>
						<li><a href="#">Blog</a></li>
						<li><a href="#">Contact</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	</section>
	<!-- /footer section end-->
</div>
<!-- /.wrapbox ends-->
<!-- SCRIPTS, placed at the end of the document so the pages load faster
================================================== -->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/plugins.js"></script>
<script src="js/common.js"></script>
<script>
//CALL TESTIMONIAL ROTATOR
$( function() {
/*
- how to call the plugin:
$( selector ).cbpQTRotator( [options] );
- options:
{
	// default transition speed (ms)
	speed : 700,
	// default transition easing
	easing : 'ease',
	// rotator interval (ms)
	interval : 8000
}
- destroy:
$( selector ).cbpQTRotator( 'destroy' );
*/
$( '#cbp-qtrotator' ).cbpQTRotator();
} );
</script>
</body>
</html>