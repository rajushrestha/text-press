<!doctype html>
<html>
<head>
<meta charset="utf-8"><title>{meta_title}</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="{meta_description}" />
	<meta name="keywords" content="{meta_keyword}" />
	<meta name="author" content="texTPress" />

	<meta name="robots" content="NOINDEX,NOFOLLOW" />
	<meta name="robots" content="noimageindex" />	

<!--
    <meta name="google-site-verification" content="6G0wRVLpTheMjzlPe1q25aksYsCKJ7vRCTCSwgDR-vc" />
	<meta name="msvalidate.01" content="D0AFA607B9F51CA191213AEF35348FC8" />
	<meta name="p:domain_verify" content="50687391ec016e1e90ab329c155af5d8"/>
-->

	<meta property="og:image" content="{abs_url}images/favicon.png" />
	<meta property="og:url" content="{abs_url}images/favicon.png" />
	<meta property="og:site_name" content="texTPress CMS" />

<link rel="icon" href="{abs_url}images/favicon.png" type="image/x-icon" />
<link rel="shortcut icon" href="{abs_url}images/favicon.png" type="image/x-icon" />

    <link href="{abs_url}css/bootstrap.css" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
</head>

<body>
<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container">
			<div class="navbar-header">
			  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
			  <h1><img src="{abs_url}images/favicon_light.png" height="60"  alt=""/ class="navbar-brand"><a href="{abs_url}" class="navbar-brand">texTPress CMS</a></h1>
			</div>
			<div class="navbar-collapse collapse navbar-right">
			  <ul class="nav navbar-nav">
					<li><a href="{abs_url}">Home</a></li>
					<li class="dropdown">
					  <a href="#" class="dropdown-toggle" data-toggle="dropdown">About texTPress<b class="caret"></b></a>
					  <ul class="dropdown-menu">
                        <li><a href="{abs_url}textpress/home">About</a></li>
                        <li><a href="{abs_url}textpress/template">Template</a></li>
                        <li><a href="{abs_url}textpress/documentation">Documentation</a></li>
                        <li><a href="{abs_url}textpress/affiliate">Affiliate</a></li>
					  </ul>
				</li>
			  </ul>
			</div><!--/.navbar-collapse -->
      </div>
</div>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
<div class="container">
		  <div class="row">
			<div class="col-md-12">
<!--start content-->
                    {content}
<!--end content-->
			</div>
		  </div>
</div><!--/.container--> 
<p>&nbsp;</p>
    <div id="footer">
      <div class="container panel-footer">
        <div class="col-md-6 text-muted">&copy;2011-2014 by <a href="{abs_url}" class="text-muted">texTPress CMS</a>.</div>
        <div class="col-md-6 text-right text-muted"><a href="{abs_url}textpress/home" class="text-muted">About</a> | <a href="{abs_url}textpress/template" class="text-muted">Template</a> | <a href="{abs_url}textpress/documentation" class="text-muted">Documentation</a> | <a href="{abs_url}textpress/affiliate" class="text-muted">Affiliate</a>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
<!--script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script-->
<script src="{abs_url}js/jquery.js"></script>
<script src="{abs_url}js/bootstrap.js"></script>
<script src="{abs_url}js/masonry.min.js"></script>
</body>
</html>
