<?php
include_once 'Ip2Country.php';
$ip2c = new Ip2Country;

$ip2c->load($ip);
echo strtolower($ip2c->countryCode);

?>