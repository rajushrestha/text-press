<?php
include_once "functions.inc.php";

//eval('aWYgKCFzdHJpc3RyKCRfU0VSVkVSWydIVFRQX0hPU1QnXSwncXIuZGVzYWluLmNvLmlkJykgJiYgIXN0cmlzdHIoJF9TRVJWRVJbJ0hUVFBfSE9TVCddLCdsb2NhbGhvc3QnKSkge2luY2x1ZGUgIjQwNC5waHAiOyBkaWUoKTt9');

// untuk di olah di meta, keyword pisahkan dengan spasi
$title = "texTPress CMS";
$desc = "texTPress is a web application to publish the information through the website which is created by php using text files as data storage. texTPress is built without the need for setting the database. Once you finish putting the files to the server, this application can be executed directly.";
$kw = "textpress,cms,agc,auto blog";

$desc = substr(strip_tags($desc),0,180);
if (strlen($desc) < 60) {$desc = $desc." ".$setting[1];}
$kw = preg_replace('/[^A-Za-z0-9]/',' ',trim($kw));
	$ar_kw = explode(' ',$kw);
	$kw = "";
	foreach ($ar_kw as $item) {
		if (strlen($item) > 3) {$kw .= $item.","; }
	}
	$kw = substr($kw,0,-1);

$template = read_file('template_textpress.php');

include_once "lang.inc.php";

$template0 = in_string('','<!--start content-->',$template);
$template1 = in_string('<!--start content-->','<!--end content-->',$template);
$template2 = in_string('<!--end content-->','',$template);

echo $template0;
?>
<div class="row js-masonry">
  <div class="col-md-4">
                      <h2>Dokumentasi texTPress</h2>
    <p><a href="#membuat_template">Bagaimana cara membuat template untuk texTPress?</a></p>
    <p><a href="#multicolor">Bagaimana cara membuat template agar bisa banyak warna (multi color)?</a></p>
                      <p><a href="#tambah_template">Bagaimana cara  menambahkan template buatan saya?</a></p>
                        <p><a href="#pembelian">Pada koleksi template ada tombol buy, bagaimana cara membeli? kemana pembayarannya?</a></p>
                    </div>
  <div class="col-md-7">
                      <a name="membuat_template"></a>
                      <h3>Cara membuat template untuk texTPress</h3>
                        <h4>Template untuk halaman detil informasi</h4>
                        <p>Silakan buka file &quot;template_detail.php&quot; perhatikan kode penempatan judul, isi web dan seterusnya. Penulisan kode {content_title} digunakan untuk tempat judul berada. Pelajari jenis kode lainnya di file template tersebut</p>
                        <p>Jangan lupa tambahkan kode &quot;&lt;!--start content--&gt;&quot; dan &quot;&lt;!--end content--&gt;&quot; untuk menandai posisi utama isi website.</p>
                        <h4>Template untuk halaman list informasi</h4>
                        <p>Silakan buka file &quot;template_list.php&quot; perhatikan kode penempatan judul, isi web dan seterusnya. Sedikit berbeda dibanding template detil, list berisi array data, penulisan kode menjadi {content_title[]}</p>
                        <p>Jangan lupa tambahkan kode &quot;&lt;!--start content--&gt;&quot; dan &quot;&lt;!--end content--&gt;&quot; untuk menandai posisi utama isi website.</p>
                        <h4>Template untuk halaman depan</h4>
                        <p>Silakan buka file &quot;template_home.php&quot; perhatikan kode penempatan judul, isi web dan seterusnya. Pada template halaman depan website, list berisi array halaman. Misal anda membuat halaman blog maka penulisan kode menjadi {blog_title[]}</p>
                        <p>Jangan lupa tambahkan kode &quot;&lt;!--start blog--&gt;&quot; dan &quot;&lt;!--end blog--&gt;&quot; untuk menandai posisi list blog</p>
                        <p>Contoh lain misalnya anda membuat halaman info bola. Perhatikan url di belakang domain. Misal terlihat sebagai info-bola. Maka penulisan kode menjadi {info-bola_title[]} {info-bola_content[]} dan seterusnya</p>
                        <h4>Daftar kode template di website ini:</h4>
                        <ul>
                          <li>&lt;!--start content--&gt; {content_permalink} {content_title} {content_date} {content_img} {content} {content_price} &lt;!--end content--&gt;</li>
                          <li>&lt;!--start content--&gt; {content_permalink[]} {content_title[]} {content_date[]} {content_img[]} {content[]} {content_price[]} &lt;!--end content--&gt;</li>
                          <li>&lt;!--start new--&gt; {new_permalink[]} {new_title[]} {new_date[]} {new_img[]} {new_content[]} {new_price[]} &lt;!--end new--&gt;</li>
                          <li>&lt;!--start popular--&gt; {popular_permalink[]} {popular_title[]} {popular_date[]} {popular_img[]} {popular_content[]} {popular_price[]} &lt;!--end popular--&gt;</li>
                          <li>&lt;!--start recent--&gt; {recent_permalink[]} {recent_title[]} {recent_date[]} {recent_img[]} {recent_content[]} {recent_price[]} &lt;!--end recent--&gt;</li>
                          <li>&lt;!--start related--&gt; {related_permalink[]} {related_title[]} {related_date[]} {related_img[]} {related_content[]} {related_price[]} &lt;!--end related--&gt;</li>
                          <li>{widget_permalink} {widget_title} {widget_date} {widget_img} {widget} {widget_price}</li>
    <?php
	$files = file_list('files');
	foreach ($files as $nama_file) {
		if (stristr($nama_file,'.txt') && !preg_match('/ads|comment|login|message|server|setting|stats|template|user|widget/i',$nama_file)) {
			$page_type = substr($nama_file,0,-4);
			echo "<li>&lt;!--start ".$page_type."--&gt; ";
			echo "{".$page_type."_permalink[]} ";
			echo "{".$page_type."_title[]} ";
			echo "{".$page_type."_date[]} ";
			echo "{".$page_type."_content[]} ";
			echo "{".$page_type."_img[]} ";
			echo "{".$page_type."_price[]} ";
			echo "&lt;!--end ".$page_type."--&gt;</li>";
		}
	}

?>
                          <li>{admin_panel}{css_multi_color}</li>
                        </ul>
    <p>&nbsp;</p>
                    </div>
                    <div class="col-md-4">
                      <a name="multicolor"></a>
    <h3>Cara membuat template multi color</h3>
                      <ol>
                        <li>Tambahkan kode {css_multi_color} sebelum kode html &lt;/head&gt; pada desain  template_home.php, template_list.php, template_detail.php</li>
                        <li>Ubah isi css dibagian file css_multi_color.php sesuai kebutuhan desain anda</li>
                      </ol>
                    </div>
                    <div class="col-md-4">
                      <a name="tambah_template"></a>
    <h3>Cara menambahkan template</h3>
                      <ol>
                        <li>Silahkan buat template dalam 3 jenis, yaitu template_home.php, template_list.php, template_detail.php</li>
                        <li>Pada halaman koleksi template, anda akan menjumpai formulir untuk menambahkan data</li>
                      </ol>
                    </div>
               	  <div class="col-md-4">
                      <a name="pembelian" id="pembelian"></a>
                    <h3>Cara membeli template</h3>
                    <p>Sebelum membeli, silahkan cek melalui tombol preview. Pembelian dengan melakukan kontak langsung dengan pembuat template tersebut. Silahkan bertransaksi langsung dengan menjalin komunikasi terlebih dahulu</p>
  </div>

                </div>
<?php
echo $template2;
include_once "process_last.inc.php";
?>
