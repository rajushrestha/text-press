<?php
include_once "functions.inc.php";

?>
<script src="mootools.v1.11.js" type="text/javascript"></script>
<script src="nogray_core_vs1_min.js" type="text/javascript"></script>
<script src="nogray_color_picker_vs2_min.js" type="text/javascript"></script>
<style type="text/css">
<!--
.hand_cursor {	cursor: hand;
}
-->
</style>

<script language="javascript">
	window.addEvent('domready', function(){
		var color1 = new ColorPicker('Color1', 'Color1_div',{color:'<?=$mono[1]?>'});
		var color2 = new ColorPicker('Color_a', 'Color_a_div', {onComplete: function(){
				alert(this.color);
			}
		});
		var color3 = new ColorPicker('Color2', 'Color2_div', {color:'#0000FF'});
		var color4 = new ColorPicker('Color3');
		var color5 = new ColorPicker('Color4', 'Color4');
	});
</script>
<style>
	* {font-family:Arial, Helvetica, sans-serif;
		font-size:9pt;}
	.sample_swatch {float:left;
		width:20px;
		height:20px;
		cursor:pointer;}
		
	/* table list */
	.table_list {border-collapse:collapse;
		border:solid #cccccc 1px;
		width:100%;}
	
	.table_list td {padding:5px;
		border:solid #efefef 1px;}
	
	.table_list th {background:#75b2d1;
		padding:5px;
		color:#ffffff;}
	
	.table_list tr.odd {background:#e1eff5;}
.sample_swatch1 {float:left;
		width:20px;
		height:20px;
		cursor:pointer;}
.sample_swatch1 {float:left;
		width:20px;
		height:20px;
		cursor:pointer;}
</style> 

	<!-- input form. you can press enter too -->
	<h2>Choose color base </h2>
	<p>Computer will computing color harmony base on your picked color </p>
	<p>&nbsp;</p>
	<form action="<? echo $_COOKIE['prev']; ?>" method="POST" target="_parent">
                    <div id="Color1_div" class="sample_swatch1" style="background:#ff0000;">&nbsp;</div>
                    <input name="bgcolor" type="text" id="Color1" size="8" maxlength="7" />
                    <input name="Submit" type="submit" class="hand_cursor" value=":: Change theme ::." />
    </form>
	<br />