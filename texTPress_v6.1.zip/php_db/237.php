<?php $entries = array(
array('2372337664','2372403199','ID'),
);