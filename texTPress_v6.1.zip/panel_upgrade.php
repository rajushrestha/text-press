<?php include_once "ijin_user.inc.php";?>
<?php
include_once "functions.inc.php";

if ($_POST['activation_code'] != '') {
	$install_data[1] = "InstallDate" ;
	$install_data[2] = $_POST['install_date'] ;
	$install_data[3] = strrev(base64_decode($_POST['activation_code']));
	$install_data[4] = getenv("HTTP_USER_AGENT");
	replace_db('files/setting.txt',$install_data,'InstallDate'); 
	redirect($abs_url.'panel'); die();
}

// untuk di olah di meta, keyword pisahkan dengan spasi
$title = $content_detil[3];
$desc = strip_tags(cuplik($content_detil[4],180));
$kw = $path[0]." ".$content_detil[3];

$desc = substr(strip_tags($desc),0,180);
if (strlen($desc) < 60) {$desc = $desc." ".$setting[1];}
$kw = preg_replace('/[^A-Za-z0-9]/',' ',trim($kw));
	$ar_kw = explode(' ',$kw);
	$kw = "";
	foreach ($ar_kw as $item) {
		if (strlen($item) > 3) {$kw .= $item.","; }
	}
	$kw = substr($kw,0,-1);

if (!file_exists('files/template_detail.php')) {$template = read_file('template_detail.php');}
if (file_exists('files/template_detail.php')) {$template = read_file('files/template_detail.php');}


include_once "page_new.inc.php";
include_once "page_recent.inc.php";
include_once "page_popular.inc.php";
include_once "page_related.inc.php";
include_once "page_widget.inc.php";
include_once "lang.inc.php";

$template0 = in_string('','<!--start content-->',$template);
$template1 = in_string('<!--start content-->','<!--end content-->',$template);
$template2 = in_string('<!--end content-->','',$template);

echo $template0;
?>
<p>&nbsp;</p>
<div class="row">
	<div class="col-md-7">
    	<h3><?php if ($lang == 'en') {echo "License code";} if ($lang == 'id') {echo "Kode lisensi";}?></h3>
                  <p><?=$text_activate?></p>
                  <form id="form1" name="form1" method="post">
                    <p>
                      <input name="activation_code" type="text" required id="activation_code" size="33" class="form form-control">
                    </p>
                    <p>
                      <input type="submit" name="submit" id="submit" value="<?=$btn_activate?>">
                      <input name="install_date" type="hidden" id="install_date" value="<?=$setting[InstallDate][2]?>">
                    </p>
                  </form>
                  <p>&nbsp;</p>
	</div>
	<div class="col-md-5">
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p><?=$text_activation_note?></p>
                  <p>&nbsp;</p>
    </div>
	<div class="col-md-12">
<?php
if ($lang == 'en') {
?>
                  <p>License price: <strong>$40 (USD)</strong></p>
<?php }?>
<?php
if ($lang == 'id') {
?>
                  <p>Harga lisensi: <strong>Rp 400.000 ,-</strong></p>
<?php }?>
                  <p><?=$text_textpress_contact?></p>
                  <p>&nbsp;</p>
    </div>
</div>
<?php
echo $template2;
?>
<?php 
include_once "process_last.inc.php";
if ($pesan != '') {
	echo "<script type=\"text/javascript\">alert('".$pesan."');</script>";
	$pesan = '';
	redirect($_SERVER['REQUEST_URI'], 0.1);
}
?>
