
			  <ul class="nav navbar-nav">
			    <li class="dropdown active"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Admin Panel<b class="caret"></b></a>
                   <ul class="dropdown-menu">
			        <li><a href="{abs_url}panel">Beranda Panel</a></li>
			        <li class="divider"></li>
			        <li class="dropdown-header">Seting Website</li>
			        <!--li><a href="{abs_url}change-template">Ubah Template</a></li-->
			        <li><a href="{abs_url}meta-tags">Meta Tags</a></li>
			        <li class="divider"></li>
			        <li class="dropdown-header">Seting Pribadi</li>
			        <li><a href="{abs_url}change-password">Ubah Password</a></li>
			        <li><a href="{abs_url}logout">Logout</a></li>
		          </ul>
                </li>
		      </ul>
