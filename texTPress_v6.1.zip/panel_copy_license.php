<?php include_once "ijin_user.inc.php";?>
<?php
include_once "functions.inc.php";

// untuk di olah di meta, keyword pisahkan dengan spasi
$title = $content_detil[3];
$desc = strip_tags(cuplik($content_detil[4],180));
$kw = $path[0]." ".$content_detil[3];

$desc = substr(strip_tags($desc),0,180);
if (strlen($desc) < 60) {$desc = $desc." ".$setting[1];}
$kw = preg_replace('/[^A-Za-z0-9]/',' ',trim($kw));
	$ar_kw = explode(' ',$kw);
	$kw = "";
	foreach ($ar_kw as $item) {
		if (strlen($item) > 3) {$kw .= $item.","; }
	}
	$kw = substr($kw,0,-1);

if (!file_exists('files/template_detail.php')) {$template = read_file('template_detail.php');}
if (file_exists('files/template_detail.php')) {$template = read_file('files/template_detail.php');}


include_once "page_new.inc.php";
include_once "page_recent.inc.php";
include_once "page_popular.inc.php";
include_once "page_related.inc.php";
include_once "page_widget.inc.php";
include_once "lang.inc.php";

$template0 = in_string('','<!--start content-->',$template);
$template1 = in_string('<!--start content-->','<!--end content-->',$template);
$template2 = in_string('<!--end content-->','',$template);

echo $template0;
?>
<p>&nbsp;</p>
<div class="row">
  <div class="col-md-8">
<?php if ($lang == 'en') {?>
    <h3>Duplicate license code</h3>
        
                <p>You can create website at subdomain without buy license again. Please copy paste the following license code at your subdomain:</p>
                  <p>
                    <textarea name="textarea" cols="44" rows="4" id="textarea" class="form-control"><?php if (strlen($setting[InstallDate][3]) > 11) {echo $setting[InstallDate][3];}?></textarea>
                  </p>
<?php }?>
<?php if ($lang == 'id') {?>
    <h3>Duplikat kode lisensi</h3>
        
                <p>Anda bisa membuat website di subdomain tanpa membeli lisensi lagi. Silahkan copy paste kode lisensi berikut di subdomain yang anda buat:</p>
                  <p>
                    <textarea name="textarea" cols="44" rows="4" id="textarea" class="form-control"><?php if (strlen($setting[InstallDate][3]) > 11) {echo $setting[InstallDate][3];}?></textarea>
                  </p>
<?php }?>
  </div>
</div>
<?php
echo $template2;
?>
<?php 
include_once "process_last.inc.php";
if ($pesan != '') {
	echo "<script type=\"text/javascript\">alert('".$pesan."');</script>";
	$pesan = '';
	redirect($_SERVER['REQUEST_URI'], 0.1);
}
?>
